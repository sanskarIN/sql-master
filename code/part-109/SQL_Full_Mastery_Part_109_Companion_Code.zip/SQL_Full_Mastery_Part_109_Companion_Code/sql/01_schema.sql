-- SQL Full Mastery - Part 109
-- Banking Ledger and Double-Entry Design
-- Primary target: PostgreSQL 15+
-- Author: Ram Sandesh

BEGIN;
CREATE SCHEMA IF NOT EXISTS ledger;
SET search_path = ledger, public;

CREATE TYPE account_kind AS ENUM
    ('CUSTOMER_LIABILITY','CASH_ASSET','SETTLEMENT_ASSET','FEE_INCOME','EXPENSE','SUSPENSE');
CREATE TYPE account_status AS ENUM ('PENDING','ACTIVE','FROZEN','CLOSED');
CREATE TYPE entry_status AS ENUM ('DRAFT','POSTED','REVERSED');
CREATE TYPE posting_side AS ENUM ('DEBIT','CREDIT');
CREATE TYPE hold_status AS ENUM ('ACTIVE','CAPTURED','RELEASED','EXPIRED');

CREATE TABLE legal_entities (
    entity_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_code     VARCHAR(24) NOT NULL UNIQUE,
    entity_name     VARCHAR(160) NOT NULL,
    base_currency   CHAR(3) NOT NULL DEFAULT 'INR',
    timezone_name   VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
    customer_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_id        BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    customer_number  VARCHAR(40) NOT NULL,
    display_name     VARCHAR(160) NOT NULL,
    status           VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                     CHECK (status IN ('ACTIVE','BLOCKED','CLOSED')),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (entity_id, customer_number)
);

CREATE TABLE ledger_accounts (
    account_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_id         BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    customer_id       BIGINT REFERENCES customers(customer_id),
    account_number    VARCHAR(48) NOT NULL,
    account_name      VARCHAR(160) NOT NULL,
    kind              account_kind NOT NULL,
    currency_code     CHAR(3) NOT NULL,
    status            account_status NOT NULL DEFAULT 'PENDING',
    overdraft_minor   BIGINT NOT NULL DEFAULT 0 CHECK (overdraft_minor >= 0),
    opened_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    closed_at         TIMESTAMPTZ,
    version_no        INTEGER NOT NULL DEFAULT 1 CHECK (version_no > 0),
    CHECK ((kind = 'CUSTOMER_LIABILITY' AND customer_id IS NOT NULL)
        OR (kind <> 'CUSTOMER_LIABILITY' AND customer_id IS NULL)),
    CHECK (closed_at IS NULL OR closed_at >= opened_at),
    UNIQUE (entity_id, account_number)
);

CREATE TABLE command_requests (
    command_id       UUID PRIMARY KEY,
    entity_id        BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    command_type     VARCHAR(40) NOT NULL,
    idempotency_key  VARCHAR(160) NOT NULL,
    request_hash     CHAR(64) NOT NULL,
    status           VARCHAR(16) NOT NULL DEFAULT 'STARTED'
                     CHECK (status IN ('STARTED','SUCCEEDED','FAILED')),
    result_entry_id  BIGINT,
    error_code       VARCHAR(60),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at     TIMESTAMPTZ,
    UNIQUE (entity_id, command_type, idempotency_key)
);

CREATE TABLE journal_entries (
    entry_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_id          BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    entry_reference    VARCHAR(80) NOT NULL,
    entry_type         VARCHAR(40) NOT NULL,
    status             entry_status NOT NULL DEFAULT 'DRAFT',
    effective_at       TIMESTAMPTZ NOT NULL,
    posted_at          TIMESTAMPTZ,
    description_text   VARCHAR(500) NOT NULL,
    command_id         UUID REFERENCES command_requests(command_id),
    reversal_of_entry_id BIGINT REFERENCES journal_entries(entry_id),
    metadata_json      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK ((status = 'POSTED' AND posted_at IS NOT NULL)
        OR (status <> 'POSTED')),
    CHECK (reversal_of_entry_id IS NULL OR reversal_of_entry_id <> entry_id),
    UNIQUE (entity_id, entry_reference),
    UNIQUE (reversal_of_entry_id)
);

ALTER TABLE command_requests
    ADD CONSTRAINT fk_command_result_entry
    FOREIGN KEY (result_entry_id) REFERENCES journal_entries(entry_id);

CREATE TABLE journal_postings (
    posting_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entry_id         BIGINT NOT NULL REFERENCES journal_entries(entry_id),
    line_no          SMALLINT NOT NULL CHECK (line_no > 0),
    account_id       BIGINT NOT NULL REFERENCES ledger_accounts(account_id),
    side             posting_side NOT NULL,
    amount_minor     BIGINT NOT NULL CHECK (amount_minor > 0),
    currency_code    CHAR(3) NOT NULL,
    narrative_text   VARCHAR(240),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (entry_id, line_no)
);

CREATE TABLE account_holds (
    hold_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_id        BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    account_id       BIGINT NOT NULL REFERENCES ledger_accounts(account_id),
    external_ref     VARCHAR(120) NOT NULL,
    amount_minor     BIGINT NOT NULL CHECK (amount_minor > 0),
    currency_code    CHAR(3) NOT NULL,
    status           hold_status NOT NULL DEFAULT 'ACTIVE',
    expires_at       TIMESTAMPTZ,
    captured_entry_id BIGINT REFERENCES journal_entries(entry_id),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (entity_id, external_ref),
    CHECK ((status = 'CAPTURED' AND captured_entry_id IS NOT NULL)
        OR (status <> 'CAPTURED'))
);

CREATE TABLE external_statement_lines (
    statement_line_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_id         BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    source_code       VARCHAR(40) NOT NULL,
    external_ref      VARCHAR(160) NOT NULL,
    value_date        DATE NOT NULL,
    amount_minor      BIGINT NOT NULL,
    currency_code     CHAR(3) NOT NULL,
    payload_hash      CHAR(64) NOT NULL,
    imported_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (entity_id, source_code, external_ref)
);

CREATE TABLE reconciliation_runs (
    run_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_id        BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    source_code      VARCHAR(40) NOT NULL,
    period_start     DATE NOT NULL,
    period_end       DATE NOT NULL,
    status           VARCHAR(16) NOT NULL DEFAULT 'RUNNING'
                     CHECK (status IN ('RUNNING','COMPLETED','FAILED')),
    started_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at     TIMESTAMPTZ,
    CHECK (period_end >= period_start)
);

CREATE TABLE reconciliation_items (
    item_id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id             BIGINT NOT NULL REFERENCES reconciliation_runs(run_id) ON DELETE CASCADE,
    statement_line_id  BIGINT REFERENCES external_statement_lines(statement_line_id),
    entry_id           BIGINT REFERENCES journal_entries(entry_id),
    result_code        VARCHAR(24) NOT NULL
                       CHECK (result_code IN ('MATCHED','MISSING_LEDGER','MISSING_EXTERNAL','AMOUNT_MISMATCH')),
    difference_minor   BIGINT NOT NULL DEFAULT 0,
    notes_text         VARCHAR(500),
    UNIQUE (run_id, statement_line_id, entry_id)
);

CREATE TABLE audit_events (
    audit_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    entity_id         BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    actor_type        VARCHAR(24) NOT NULL,
    actor_id          VARCHAR(120) NOT NULL,
    action_code       VARCHAR(80) NOT NULL,
    object_type       VARCHAR(60) NOT NULL,
    object_id         VARCHAR(120) NOT NULL,
    request_id        UUID,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    details_json      JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE outbox_events (
    event_id          UUID PRIMARY KEY,
    entity_id         BIGINT NOT NULL REFERENCES legal_entities(entity_id),
    aggregate_type    VARCHAR(60) NOT NULL,
    aggregate_id      VARCHAR(120) NOT NULL,
    event_type        VARCHAR(80) NOT NULL,
    payload_json      JSONB NOT NULL,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at      TIMESTAMPTZ,
    attempt_count     INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
    next_attempt_at   TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_postings_account_entry
    ON journal_postings (account_id, entry_id, posting_id);
CREATE INDEX ix_entries_entity_effective
    ON journal_entries (entity_id, effective_at DESC, entry_id DESC)
    WHERE status = 'POSTED';
CREATE INDEX ix_holds_active_account
    ON account_holds (account_id, expires_at, hold_id)
    WHERE status = 'ACTIVE';
CREATE INDEX ix_outbox_ready
    ON outbox_events (next_attempt_at, occurred_at, event_id)
    WHERE published_at IS NULL;
CREATE INDEX ix_audit_object
    ON audit_events (entity_id, object_type, object_id, occurred_at DESC);

COMMIT;
