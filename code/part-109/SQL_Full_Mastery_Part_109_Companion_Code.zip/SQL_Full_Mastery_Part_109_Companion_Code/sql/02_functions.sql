-- Posting, transfer, hold, reversal, and immutability contracts
SET search_path = ledger, public;

CREATE OR REPLACE FUNCTION assert_entry_balanced(p_entry_id BIGINT)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE
    v_status entry_status;
    v_currency_count INTEGER;
    v_unbalanced INTEGER;
BEGIN
    SELECT status INTO v_status
    FROM journal_entries
    WHERE entry_id = p_entry_id;

    IF v_status <> 'POSTED' THEN
        RETURN;
    END IF;

    SELECT COUNT(DISTINCT currency_code),
           COUNT(*) FILTER (WHERE COALESCE(debit_minor, 0) <> COALESCE(credit_minor, 0))
    INTO v_currency_count, v_unbalanced
    FROM (
        SELECT currency_code,
               SUM(amount_minor) FILTER (WHERE side = 'DEBIT') AS debit_minor,
               SUM(amount_minor) FILTER (WHERE side = 'CREDIT') AS credit_minor
        FROM journal_postings
        WHERE entry_id = p_entry_id
        GROUP BY currency_code
    ) x;

    IF v_currency_count = 0 OR v_unbalanced > 0 THEN
        RAISE EXCEPTION 'entry % is not balanced by currency', p_entry_id
            USING ERRCODE = '23514';
    END IF;
END;
$$;

CREATE OR REPLACE FUNCTION trg_assert_posted_entry_balanced()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    PERFORM assert_entry_balanced(COALESCE(NEW.entry_id, OLD.entry_id));
    RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE CONSTRAINT TRIGGER ct_posting_balance
AFTER INSERT OR UPDATE OR DELETE ON journal_postings
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION trg_assert_posted_entry_balanced();

CREATE CONSTRAINT TRIGGER ct_entry_balance
AFTER INSERT OR UPDATE OF status ON journal_entries
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION trg_assert_posted_entry_balanced();

CREATE OR REPLACE FUNCTION protect_posted_ledger_rows()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE v_status entry_status;
BEGIN
    SELECT status INTO v_status
    FROM journal_entries
    WHERE entry_id = COALESCE(OLD.entry_id, NEW.entry_id);
    IF v_status IN ('POSTED','REVERSED') THEN
        RAISE EXCEPTION 'posted ledger rows are immutable; create a reversal';
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER bu_postings_immutable
BEFORE UPDATE OR DELETE ON journal_postings
FOR EACH ROW EXECUTE FUNCTION protect_posted_ledger_rows();

CREATE OR REPLACE FUNCTION prevent_posted_entry_rewrite()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.status IN ('POSTED','REVERSED') THEN
        IF NEW.entity_id IS DISTINCT FROM OLD.entity_id
        OR NEW.entry_reference IS DISTINCT FROM OLD.entry_reference
        OR NEW.entry_type IS DISTINCT FROM OLD.entry_type
        OR NEW.effective_at IS DISTINCT FROM OLD.effective_at
        OR NEW.description_text IS DISTINCT FROM OLD.description_text
        OR NEW.command_id IS DISTINCT FROM OLD.command_id
        OR NEW.reversal_of_entry_id IS DISTINCT FROM OLD.reversal_of_entry_id THEN
            RAISE EXCEPTION 'posted journal entry facts are immutable';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER bu_entries_immutable
BEFORE UPDATE ON journal_entries
FOR EACH ROW EXECUTE FUNCTION prevent_posted_entry_rewrite();

CREATE OR REPLACE VIEW account_ledger_balances AS
SELECT a.account_id,
       a.entity_id,
       a.account_number,
       a.kind,
       a.currency_code,
       COALESCE(SUM(CASE
           WHEN e.entry_id IS NULL THEN 0
           WHEN a.kind = 'CUSTOMER_LIABILITY' AND p.side = 'CREDIT' THEN p.amount_minor
           WHEN a.kind = 'CUSTOMER_LIABILITY' AND p.side = 'DEBIT'  THEN -p.amount_minor
           WHEN a.kind <> 'CUSTOMER_LIABILITY' AND p.side = 'DEBIT' THEN p.amount_minor
           ELSE -p.amount_minor END), 0)::BIGINT AS ledger_balance_minor
FROM ledger_accounts a
LEFT JOIN journal_postings p ON p.account_id = a.account_id
LEFT JOIN journal_entries e ON e.entry_id = p.entry_id AND e.status IN ('POSTED','REVERSED')
GROUP BY a.account_id, a.entity_id, a.account_number, a.kind, a.currency_code;

CREATE OR REPLACE VIEW account_available_balances AS
SELECT b.*,
       COALESCE(h.active_hold_minor, 0)::BIGINT AS active_hold_minor,
       (b.ledger_balance_minor - COALESCE(h.active_hold_minor, 0))::BIGINT AS available_balance_minor
FROM account_ledger_balances b
LEFT JOIN (
    SELECT account_id, SUM(amount_minor)::BIGINT AS active_hold_minor
    FROM account_holds
    WHERE status = 'ACTIVE'
      AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)
    GROUP BY account_id
) h USING (account_id);

CREATE OR REPLACE FUNCTION post_internal_transfer(
    p_entity_id BIGINT,
    p_command_id UUID,
    p_idempotency_key VARCHAR,
    p_request_hash CHAR(64),
    p_source_account_id BIGINT,
    p_destination_account_id BIGINT,
    p_amount_minor BIGINT,
    p_currency_code CHAR(3),
    p_effective_at TIMESTAMPTZ,
    p_description VARCHAR
) RETURNS BIGINT LANGUAGE plpgsql AS $$
DECLARE
    v_existing command_requests%ROWTYPE;
    v_source ledger_accounts%ROWTYPE;
    v_destination ledger_accounts%ROWTYPE;
    v_available BIGINT;
    v_entry_id BIGINT;
BEGIN
    IF p_amount_minor <= 0 OR p_source_account_id = p_destination_account_id THEN
        RAISE EXCEPTION 'invalid transfer request';
    END IF;

    INSERT INTO command_requests
        (command_id, entity_id, command_type, idempotency_key, request_hash)
    VALUES
        (p_command_id, p_entity_id, 'INTERNAL_TRANSFER', p_idempotency_key, p_request_hash)
    ON CONFLICT (entity_id, command_type, idempotency_key) DO NOTHING;

    SELECT * INTO v_existing
    FROM command_requests
    WHERE entity_id = p_entity_id
      AND command_type = 'INTERNAL_TRANSFER'
      AND idempotency_key = p_idempotency_key
    FOR UPDATE;

    IF v_existing.request_hash <> p_request_hash THEN
        RAISE EXCEPTION 'idempotency key reused with a different request';
    END IF;
    IF v_existing.status = 'SUCCEEDED' THEN
        RETURN v_existing.result_entry_id;
    END IF;

    -- Deterministic row-lock order prevents avoidable deadlocks.
    PERFORM 1
    FROM ledger_accounts
    WHERE account_id IN (p_source_account_id, p_destination_account_id)
    ORDER BY account_id
    FOR UPDATE;

    SELECT * INTO STRICT v_source FROM ledger_accounts WHERE account_id = p_source_account_id;
    SELECT * INTO STRICT v_destination FROM ledger_accounts WHERE account_id = p_destination_account_id;

    IF v_source.entity_id <> p_entity_id OR v_destination.entity_id <> p_entity_id
       OR v_source.currency_code <> p_currency_code
       OR v_destination.currency_code <> p_currency_code
       OR v_source.status <> 'ACTIVE' OR v_destination.status <> 'ACTIVE' THEN
        RAISE EXCEPTION 'account scope, currency, or status mismatch';
    END IF;

    SELECT available_balance_minor INTO v_available
    FROM account_available_balances
    WHERE account_id = p_source_account_id;

    IF v_available + v_source.overdraft_minor < p_amount_minor THEN
        RAISE EXCEPTION 'insufficient available balance';
    END IF;

    INSERT INTO journal_entries
        (entity_id, entry_reference, entry_type, status, effective_at, posted_at,
         description_text, command_id)
    VALUES
        (p_entity_id, 'TRF-' || p_command_id::text, 'INTERNAL_TRANSFER', 'DRAFT',
         p_effective_at, NULL, p_description, p_command_id)
    RETURNING entry_id INTO v_entry_id;

    INSERT INTO journal_postings
        (entry_id, line_no, account_id, side, amount_minor, currency_code, narrative_text)
    VALUES
        (v_entry_id, 1, p_source_account_id, 'DEBIT', p_amount_minor, p_currency_code, 'Transfer out'),
        (v_entry_id, 2, p_destination_account_id, 'CREDIT', p_amount_minor, p_currency_code, 'Transfer in');

    UPDATE journal_entries
    SET status = 'POSTED', posted_at = CURRENT_TIMESTAMP
    WHERE entry_id = v_entry_id AND status = 'DRAFT';

    PERFORM assert_entry_balanced(v_entry_id);

    INSERT INTO outbox_events
        (event_id, entity_id, aggregate_type, aggregate_id, event_type, payload_json)
    VALUES
        (gen_random_uuid(), p_entity_id, 'JOURNAL_ENTRY', v_entry_id::text,
         'ledger.transfer.posted', jsonb_build_object('entry_id', v_entry_id));

    UPDATE command_requests
    SET status = 'SUCCEEDED', result_entry_id = v_entry_id, completed_at = CURRENT_TIMESTAMP
    WHERE command_id = v_existing.command_id;

    RETURN v_entry_id;
EXCEPTION WHEN OTHERS THEN
    -- The caller owns failure classification. A re-raised database error rolls back
    -- this transaction, so durable FAILED recording belongs in a separate recovery unit.
    RAISE;
END;
$$;

CREATE OR REPLACE FUNCTION reverse_entry(
    p_entity_id BIGINT,
    p_original_entry_id BIGINT,
    p_entry_reference VARCHAR,
    p_effective_at TIMESTAMPTZ,
    p_reason VARCHAR
) RETURNS BIGINT LANGUAGE plpgsql AS $$
DECLARE v_reversal_id BIGINT;
BEGIN
    PERFORM 1 FROM journal_entries
    WHERE entry_id = p_original_entry_id
      AND entity_id = p_entity_id
      AND status = 'POSTED'
    FOR UPDATE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'original posted entry not found';
    END IF;

    INSERT INTO journal_entries
        (entity_id, entry_reference, entry_type, status, effective_at,
         description_text, reversal_of_entry_id)
    VALUES
        (p_entity_id, p_entry_reference, 'REVERSAL', 'DRAFT', p_effective_at,
         p_reason, p_original_entry_id)
    RETURNING entry_id INTO v_reversal_id;

    INSERT INTO journal_postings
        (entry_id, line_no, account_id, side, amount_minor, currency_code, narrative_text)
    SELECT v_reversal_id,
           row_number() OVER (ORDER BY line_no),
           account_id,
           CASE side WHEN 'DEBIT' THEN 'CREDIT'::posting_side ELSE 'DEBIT'::posting_side END,
           amount_minor,
           currency_code,
           'Reversal of entry ' || p_original_entry_id
    FROM journal_postings
    WHERE entry_id = p_original_entry_id;

    UPDATE journal_entries
    SET status = 'POSTED', posted_at = CURRENT_TIMESTAMP
    WHERE entry_id = v_reversal_id;

    UPDATE journal_entries
    SET status = 'REVERSED'
    WHERE entry_id = p_original_entry_id;

    PERFORM assert_entry_balanced(v_reversal_id);
    RETURN v_reversal_id;
END;
$$;
