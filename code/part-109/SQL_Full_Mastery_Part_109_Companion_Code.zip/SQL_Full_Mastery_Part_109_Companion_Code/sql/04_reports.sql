SET search_path = ledger, public;

-- Account statement with deterministic running balance for liability accounts.
SELECT a.account_number,
       e.entry_id,
       e.entry_reference,
       e.effective_at,
       p.posting_id,
       p.side,
       p.amount_minor,
       SUM(CASE WHEN p.side='CREDIT' THEN p.amount_minor ELSE -p.amount_minor END)
         OVER (PARTITION BY a.account_id
               ORDER BY e.effective_at, e.entry_id, p.posting_id
               ROWS UNBOUNDED PRECEDING) AS running_balance_minor
FROM ledger_accounts a
JOIN journal_postings p ON p.account_id=a.account_id
JOIN journal_entries e ON e.entry_id=p.entry_id
WHERE a.account_number = :'account_number'
  AND e.status IN ('POSTED','REVERSED')
ORDER BY e.effective_at, e.entry_id, p.posting_id;

-- Trial balance by account and currency.
SELECT a.currency_code,
       a.account_number,
       a.account_name,
       COALESCE(SUM(p.amount_minor) FILTER (WHERE p.side='DEBIT'),0) AS debit_minor,
       COALESCE(SUM(p.amount_minor) FILTER (WHERE p.side='CREDIT'),0) AS credit_minor,
       COALESCE(SUM(CASE WHEN p.side='DEBIT' THEN p.amount_minor ELSE -p.amount_minor END),0) AS net_debit_minor
FROM ledger_accounts a
LEFT JOIN journal_postings p ON p.account_id=a.account_id
LEFT JOIN journal_entries e ON e.entry_id=p.entry_id AND e.status IN ('POSTED','REVERSED')
GROUP BY a.currency_code, a.account_number, a.account_name
ORDER BY a.currency_code, a.account_number;

-- Daily transfer volume and value.
SELECT effective_at::date AS business_date,
       COUNT(*) AS transfer_count,
       SUM(x.amount_minor) AS transfer_value_minor
FROM journal_entries e
JOIN LATERAL (
    SELECT SUM(amount_minor) FILTER (WHERE side='DEBIT') AS amount_minor
    FROM journal_postings p WHERE p.entry_id=e.entry_id
) x ON TRUE
WHERE e.status='POSTED' AND e.entry_type='INTERNAL_TRANSFER'
GROUP BY effective_at::date
ORDER BY business_date DESC;

-- Reconciliation exception queue.
SELECT r.run_id, r.source_code, r.period_start, r.period_end,
       i.result_code, i.difference_minor,
       i.statement_line_id, i.entry_id, i.notes_text
FROM reconciliation_runs r
JOIN reconciliation_items i USING (run_id)
WHERE i.result_code <> 'MATCHED'
ORDER BY r.run_id DESC, i.item_id;

-- Outbox work queue using safe concurrent claiming.
SELECT event_id
FROM outbox_events
WHERE published_at IS NULL AND next_attempt_at <= CURRENT_TIMESTAMP
ORDER BY next_attempt_at, occurred_at, event_id
FOR UPDATE SKIP LOCKED
LIMIT 100;
