SET search_path = ledger, public;

-- 1. No posted entry may be unbalanced within any currency.
SELECT entry_id, currency_code,
       SUM(amount_minor) FILTER (WHERE side='DEBIT') AS debit_minor,
       SUM(amount_minor) FILTER (WHERE side='CREDIT') AS credit_minor
FROM journal_postings p
JOIN journal_entries e USING (entry_id)
WHERE e.status IN ('POSTED','REVERSED')
GROUP BY entry_id, currency_code
HAVING SUM(amount_minor) FILTER (WHERE side='DEBIT')
    <> SUM(amount_minor) FILTER (WHERE side='CREDIT');

-- 2. Every posting currency must match its account currency.
SELECT p.posting_id, p.currency_code, a.currency_code AS account_currency
FROM journal_postings p
JOIN ledger_accounts a USING (account_id)
WHERE p.currency_code <> a.currency_code;

-- 3. A customer liability account must not spend beyond its approved overdraft.
SELECT a.account_id, a.account_number, b.available_balance_minor, a.overdraft_minor
FROM ledger_accounts a
JOIN account_available_balances b USING (account_id)
WHERE a.kind='CUSTOMER_LIABILITY'
  AND b.available_balance_minor + a.overdraft_minor < 0;

-- 4. Captured holds must point to a posted entry.
SELECT h.hold_id, h.captured_entry_id, e.status
FROM account_holds h
LEFT JOIN journal_entries e ON e.entry_id=h.captured_entry_id
WHERE h.status='CAPTURED' AND COALESCE(e.status::text,'MISSING') <> 'POSTED';

-- 5. Reversal must mirror the original total by currency.
WITH totals AS (
    SELECT e.entry_id, e.reversal_of_entry_id, p.currency_code,
           SUM(p.amount_minor) FILTER (WHERE p.side='DEBIT') AS debit_minor,
           SUM(p.amount_minor) FILTER (WHERE p.side='CREDIT') AS credit_minor
    FROM journal_entries e JOIN journal_postings p USING (entry_id)
    GROUP BY e.entry_id, e.reversal_of_entry_id, p.currency_code
)
SELECT r.entry_id AS reversal_entry_id, o.entry_id AS original_entry_id, r.currency_code
FROM totals r
JOIN totals o ON o.entry_id=r.reversal_of_entry_id AND o.currency_code=r.currency_code
WHERE r.debit_minor <> o.credit_minor OR r.credit_minor <> o.debit_minor;

-- 6. Idempotency success must retain one authoritative result.
SELECT entity_id, command_type, idempotency_key, COUNT(*)
FROM command_requests
GROUP BY entity_id, command_type, idempotency_key
HAVING COUNT(*) <> 1;

-- 7. Global trial balance must be zero per entity and currency.
SELECT e.entity_id, p.currency_code,
       SUM(CASE WHEN p.side='DEBIT' THEN p.amount_minor ELSE -p.amount_minor END) AS difference_minor
FROM journal_entries e JOIN journal_postings p USING (entry_id)
WHERE e.status IN ('POSTED','REVERSED')
GROUP BY e.entity_id, p.currency_code
HAVING SUM(CASE WHEN p.side='DEBIT' THEN p.amount_minor ELSE -p.amount_minor END) <> 0;
