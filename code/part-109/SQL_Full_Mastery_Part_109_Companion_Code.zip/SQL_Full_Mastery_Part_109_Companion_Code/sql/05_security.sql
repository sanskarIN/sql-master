-- Illustrative least-privilege roles. Adapt names to your environment.
SET search_path = ledger, public;

CREATE ROLE ledger_app NOLOGIN;
CREATE ROLE ledger_reporter NOLOGIN;
CREATE ROLE ledger_auditor NOLOGIN;

REVOKE ALL ON SCHEMA ledger FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA ledger FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA ledger FROM PUBLIC;

GRANT USAGE ON SCHEMA ledger TO ledger_app, ledger_reporter, ledger_auditor;
GRANT SELECT, INSERT, UPDATE ON command_requests, journal_entries, journal_postings,
    account_holds, outbox_events TO ledger_app;
GRANT SELECT ON legal_entities, customers, ledger_accounts,
    account_ledger_balances, account_available_balances TO ledger_app;
GRANT EXECUTE ON FUNCTION post_internal_transfer(
    BIGINT, UUID, VARCHAR, CHAR, BIGINT, BIGINT, BIGINT, CHAR, TIMESTAMPTZ, VARCHAR
) TO ledger_app;
GRANT EXECUTE ON FUNCTION reverse_entry(BIGINT, BIGINT, VARCHAR, TIMESTAMPTZ, VARCHAR)
    TO ledger_app;

GRANT SELECT ON ledger_accounts, journal_entries, journal_postings,
    account_ledger_balances, account_available_balances TO ledger_reporter;
GRANT SELECT ON audit_events, reconciliation_runs, reconciliation_items,
    external_statement_lines TO ledger_auditor;

-- Entity isolation can be added with RLS when the application sets a trusted session value.
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY journal_entry_entity_policy ON journal_entries
USING (entity_id = current_setting('app.entity_id', true)::BIGINT)
WITH CHECK (entity_id = current_setting('app.entity_id', true)::BIGINT);
