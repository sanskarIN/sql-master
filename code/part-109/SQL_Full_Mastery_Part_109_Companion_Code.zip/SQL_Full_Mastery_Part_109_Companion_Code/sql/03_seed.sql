-- Demonstration data. Never use these identifiers as real customer data.
SET search_path = ledger, public;

INSERT INTO legal_entities (entity_code, entity_name)
VALUES ('DEMO-IN', 'Demonstration Banking Entity');

INSERT INTO customers (entity_id, customer_number, display_name)
SELECT entity_id, 'CUS-1001', 'Aarav Demo' FROM legal_entities WHERE entity_code='DEMO-IN'
UNION ALL
SELECT entity_id, 'CUS-1002', 'Meera Demo' FROM legal_entities WHERE entity_code='DEMO-IN';

INSERT INTO ledger_accounts
(entity_id, customer_id, account_number, account_name, kind, currency_code, status)
SELECT e.entity_id, c.customer_id, 'ACC-1001', 'Aarav Transaction Account', 'CUSTOMER_LIABILITY', 'INR', 'ACTIVE'
FROM legal_entities e JOIN customers c ON c.entity_id=e.entity_id AND c.customer_number='CUS-1001'
UNION ALL
SELECT e.entity_id, c.customer_id, 'ACC-1002', 'Meera Transaction Account', 'CUSTOMER_LIABILITY', 'INR', 'ACTIVE'
FROM legal_entities e JOIN customers c ON c.entity_id=e.entity_id AND c.customer_number='CUS-1002'
UNION ALL
SELECT entity_id, NULL, 'SYS-CASH', 'Settlement Cash Asset', 'CASH_ASSET', 'INR', 'ACTIVE'
FROM legal_entities WHERE entity_code='DEMO-IN'
UNION ALL
SELECT entity_id, NULL, 'SYS-FEES', 'Fee Income', 'FEE_INCOME', 'INR', 'ACTIVE'
FROM legal_entities WHERE entity_code='DEMO-IN'
UNION ALL
SELECT entity_id, NULL, 'SYS-SUSPENSE', 'Unreconciled Suspense', 'SUSPENSE', 'INR', 'ACTIVE'
FROM legal_entities WHERE entity_code='DEMO-IN';

-- Initial funding: debit cash asset, credit customer liabilities.
WITH e AS (
    INSERT INTO journal_entries
        (entity_id, entry_reference, entry_type, status, effective_at, posted_at, description_text)
    SELECT entity_id, 'OPENING-2026-001', 'OPENING_BALANCE', 'DRAFT',
           TIMESTAMPTZ '2026-08-01 09:00:00+05:30', NULL, 'Demonstration opening balances'
    FROM legal_entities WHERE entity_code='DEMO-IN'
    RETURNING entry_id, entity_id
), rows_to_post AS (
    SELECT e.entry_id, 1 line_no, a.account_id, 'DEBIT'::posting_side side, 1500000::BIGINT amount_minor
    FROM e JOIN ledger_accounts a ON a.entity_id=e.entity_id AND a.account_number='SYS-CASH'
    UNION ALL
    SELECT e.entry_id, 2, a.account_id, 'CREDIT'::posting_side, 1000000
    FROM e JOIN ledger_accounts a ON a.entity_id=e.entity_id AND a.account_number='ACC-1001'
    UNION ALL
    SELECT e.entry_id, 3, a.account_id, 'CREDIT'::posting_side, 500000
    FROM e JOIN ledger_accounts a ON a.entity_id=e.entity_id AND a.account_number='ACC-1002'
)
INSERT INTO journal_postings
(entry_id, line_no, account_id, side, amount_minor, currency_code, narrative_text)
SELECT entry_id, line_no, account_id, side, amount_minor, 'INR', 'Opening balance'
FROM rows_to_post;

UPDATE journal_entries
SET status='POSTED', posted_at=CURRENT_TIMESTAMP
WHERE entry_reference='OPENING-2026-001';
