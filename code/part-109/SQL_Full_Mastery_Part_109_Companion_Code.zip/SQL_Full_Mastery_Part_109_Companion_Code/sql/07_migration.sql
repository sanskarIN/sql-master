-- Example expand-contract migration: add a classification without rewriting history.
BEGIN;
SET search_path = ledger, public;

ALTER TABLE journal_entries
    ADD COLUMN IF NOT EXISTS channel_code VARCHAR(24);

-- Backfill in bounded batches in an operational script, not one giant transaction.
-- UPDATE journal_entries SET channel_code='LEGACY'
-- WHERE entry_id > :last_id AND entry_id <= :next_id AND channel_code IS NULL;

ALTER TABLE journal_entries
    ADD CONSTRAINT ck_entry_channel_nonblank
    CHECK (channel_code IS NULL OR btrim(channel_code) <> '') NOT VALID;

ALTER TABLE journal_entries VALIDATE CONSTRAINT ck_entry_channel_nonblank;
COMMIT;
