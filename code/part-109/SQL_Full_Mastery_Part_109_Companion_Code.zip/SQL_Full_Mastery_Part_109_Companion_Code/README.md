# SQL Full Mastery - Part 109 Companion Project

## Banking Ledger and Double-Entry Design

Author: Ram Sandesh  
Primary database: PostgreSQL 15+  
Educational portfolio project: review legal, accounting, security, and operational requirements before any real financial use.

## Included files

- `sql/01_schema.sql` - identities, accounts, entries, postings, holds, reconciliation, audit, and outbox
- `sql/02_functions.sql` - balance assertion, immutability, transfer, and reversal functions
- `sql/03_seed.sql` - demonstration entity, accounts, and balanced opening entry
- `sql/04_reports.sql` - statements, trial balance, volume, reconciliation, and outbox queries
- `sql/05_security.sql` - example least-privilege roles and entity isolation
- `sql/06_invariants.sql` - zero-row correctness checks
- `sql/07_migration.sql` - expand-contract migration example
- `tests/test_contract.py` - static SQL contract checks
- `tests/test_ledger_model.py` - in-memory property checks for balance and idempotency
- `docs/data_dictionary.md` - table grains and ownership
- `docs/operations_runbook.md` - incident and recovery playbooks

## Suggested execution order

```bash
psql -v ON_ERROR_STOP=1 -d sql_mastery_109 -f sql/01_schema.sql
psql -v ON_ERROR_STOP=1 -d sql_mastery_109 -f sql/02_functions.sql
psql -v ON_ERROR_STOP=1 -d sql_mastery_109 -f sql/03_seed.sql
psql -v ON_ERROR_STOP=1 -d sql_mastery_109 -f sql/06_invariants.sql
python -m unittest discover -s tests -v
```

Each invariant query should return zero rows. Use a dedicated local database and a non-superuser role for practice.
