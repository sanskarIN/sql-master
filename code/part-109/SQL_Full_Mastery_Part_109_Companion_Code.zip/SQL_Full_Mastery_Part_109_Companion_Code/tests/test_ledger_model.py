import random
import unittest

class Ledger:
    def __init__(self, balances):
        self.balances = dict(balances)
        self.results = {}
        self.postings = []

    def transfer(self, key, source, destination, amount):
        request = (source, destination, amount)
        if key in self.results:
            prior_request, prior_result = self.results[key]
            if prior_request != request:
                raise ValueError('idempotency conflict')
            return prior_result
        if amount <= 0 or source == destination or self.balances[source] < amount:
            raise ValueError('invalid transfer')
        self.balances[source] -= amount
        self.balances[destination] += amount
        entry_id = len(self.results) + 1
        legs = [('DEBIT', source, amount), ('CREDIT', destination, amount)]
        self.postings.append((entry_id, legs))
        self.results[key] = (request, entry_id)
        return entry_id

class LedgerModelTests(unittest.TestCase):
    def test_random_transfers_preserve_total_and_balance_each_entry(self):
        rng = random.Random(109)
        ledger = Ledger({'A': 500000, 'B': 400000, 'C': 300000})
        opening_total = sum(ledger.balances.values())
        accounts = list(ledger.balances)
        for i in range(500):
            source, destination = rng.sample(accounts, 2)
            amount = rng.randint(1, 5000)
            if ledger.balances[source] >= amount:
                ledger.transfer(f'k-{i}', source, destination, amount)
        self.assertEqual(opening_total, sum(ledger.balances.values()))
        for _, legs in ledger.postings:
            debit = sum(amount for side, _, amount in legs if side == 'DEBIT')
            credit = sum(amount for side, _, amount in legs if side == 'CREDIT')
            self.assertEqual(debit, credit)

    def test_duplicate_key_returns_same_entry_without_double_effect(self):
        ledger = Ledger({'A': 1000, 'B': 0})
        first = ledger.transfer('same-key', 'A', 'B', 250)
        snapshot = dict(ledger.balances)
        second = ledger.transfer('same-key', 'A', 'B', 250)
        self.assertEqual(first, second)
        self.assertEqual(snapshot, ledger.balances)

    def test_same_key_different_request_is_rejected(self):
        ledger = Ledger({'A': 1000, 'B': 0})
        ledger.transfer('same-key', 'A', 'B', 250)
        with self.assertRaises(ValueError):
            ledger.transfer('same-key', 'A', 'B', 251)

if __name__ == '__main__':
    unittest.main()
