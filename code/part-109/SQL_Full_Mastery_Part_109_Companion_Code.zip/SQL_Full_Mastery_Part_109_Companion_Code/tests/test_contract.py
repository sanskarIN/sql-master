import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(name):
    return (ROOT / name).read_text(encoding='utf-8')

class ContractTests(unittest.TestCase):
    def test_required_files_exist(self):
        required = [
            'sql/01_schema.sql','sql/02_functions.sql','sql/03_seed.sql',
            'sql/04_reports.sql','sql/05_security.sql','sql/06_invariants.sql',
            'sql/07_migration.sql','docs/data_dictionary.md','docs/operations_runbook.md'
        ]
        for name in required:
            self.assertTrue((ROOT / name).is_file(), name)

    def test_schema_has_ledger_contracts(self):
        text = read('sql/01_schema.sql').lower()
        for token in ['journal_entries','journal_postings','amount_minor','account_holds',
                      'command_requests','reconciliation_items','audit_events','outbox_events']:
            self.assertIn(token, text)
        self.assertRegex(text, r'check\s*\(amount_minor\s*>\s*0\)')
        self.assertIn('unique (entity_id, command_type, idempotency_key)', text)

    def test_functions_enforce_balance_and_immutability(self):
        text = read('sql/02_functions.sql').lower()
        for token in ['assert_entry_balanced','deferrable initially deferred',
                      'posted ledger rows are immutable','deterministic row-lock order',
                      'idempotency key reused','reverse_entry']:
            self.assertIn(token, text)
        self.assertIn("for update", text)

    def test_invariant_suite_has_seven_controls(self):
        text = read('sql/06_invariants.sql')
        controls = re.findall(r'^--\s+\d+\.', text, flags=re.M)
        self.assertGreaterEqual(len(controls), 7)

    def test_sql_files_are_clean(self):
        for path in (ROOT / 'sql').glob('*.sql'):
            raw = path.read_bytes()
            self.assertNotIn(b'\x00', raw, str(path))
            self.assertNotIn(b'\t', raw, str(path))

if __name__ == '__main__':
    unittest.main()
