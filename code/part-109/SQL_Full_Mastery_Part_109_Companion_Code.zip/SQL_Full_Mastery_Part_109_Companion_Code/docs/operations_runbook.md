# Operations Runbook

## Unbalanced-entry alert
1. Stop the affected posting path without editing historical rows.
2. Preserve command ID, request hash, entry ID, transaction logs, and deployment version.
3. Run `06_invariants.sql` and identify the first failing entry.
4. If the entry is posted, create an approved compensating or reversal entry.
5. Reconcile account statements, trial balance, outbox events, and external settlement.

## Ambiguous transfer outcome
1. Do not repeat the transfer with a new idempotency key.
2. Query `command_requests` by entity, command type, and original key.
3. If succeeded, return the stored entry; if started, reconcile journal and command state.
4. Retry only through the documented recovery path.

## Reconciliation difference
1. Freeze automatic resolution for the affected source and period.
2. Compare source reference, value date, currency, amount, and duplicate controls.
3. Post unresolved value to suspense only through an approved journal.
4. Retain evidence, owner, reason code, and resolution date.

## Restore proof
Restore into an isolated environment, run all invariant queries, compare trial balances and reconciliation totals, and record RPO/RTO evidence.
