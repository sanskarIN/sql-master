# Data Dictionary

| Object | Grain | Identity / rule | Owner |
|---|---|---|---|
| `legal_entities` | One regulated or accounting entity | `entity_code` unique | Platform governance |
| `customers` | One customer inside one entity | `(entity_id, customer_number)` | Customer domain |
| `ledger_accounts` | One currency-specific account | `(entity_id, account_number)` | Ledger domain |
| `command_requests` | One idempotent command | `(entity_id, command_type, idempotency_key)` | Command service |
| `journal_entries` | One balanced business event | `entry_reference` unique per entity | Ledger service |
| `journal_postings` | One debit or credit leg | `(entry_id, line_no)` | Ledger service |
| `account_holds` | One temporary availability reduction | `(entity_id, external_ref)` | Authorization domain |
| `external_statement_lines` | One imported external fact | source reference unique | Reconciliation |
| `reconciliation_items` | One comparison result | run + external + ledger references | Reconciliation |
| `audit_events` | One access or administrative event | append-only identity | Security / audit |
| `outbox_events` | One integration event | UUID | Integration worker |

Posted journals are historical facts. Correct them with a new reversal or adjustment entry, never by rewriting postings.
