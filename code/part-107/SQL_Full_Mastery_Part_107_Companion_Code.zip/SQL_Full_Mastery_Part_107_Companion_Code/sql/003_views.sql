SET search_path = school, public;

CREATE OR REPLACE VIEW v_student_directory AS
SELECT s.school_id, s.student_id, s.admission_number, p.legal_name,
       p.preferred_name, s.status,
       cs.grade_code, cs.section_code, e.roll_number
FROM students s
JOIN people p ON p.person_id = s.person_id
LEFT JOIN enrollments e ON e.student_id = s.student_id AND e.status = 'ACTIVE'
LEFT JOIN class_sections cs ON cs.class_section_id = e.class_section_id;

CREATE OR REPLACE VIEW v_attendance_summary AS
SELECT e.student_id, ar.enrollment_id,
       COUNT(*) AS marked_sessions,
       COUNT(*) FILTER (WHERE ar.attendance_status IN ('PRESENT','LATE')) AS attended_sessions,
       ROUND(100.0 * COUNT(*) FILTER (WHERE ar.attendance_status IN ('PRESENT','LATE'))
             / NULLIF(COUNT(*),0), 2) AS attendance_percent
FROM attendance_records ar
JOIN enrollments e ON e.enrollment_id = ar.enrollment_id
GROUP BY e.student_id, ar.enrollment_id;

CREATE OR REPLACE VIEW v_student_fee_balance AS
SELECT s.student_id, s.admission_number, p.legal_name,
       COALESCE(SUM(fi.total_paise),0) AS invoiced_paise,
       COALESCE(SUM(fi.outstanding_paise),0) AS outstanding_paise
FROM students s
JOIN people p ON p.person_id=s.person_id
LEFT JOIN fee_invoices fi ON fi.student_id=s.student_id AND fi.status <> 'VOID'
GROUP BY s.student_id, s.admission_number, p.legal_name;
