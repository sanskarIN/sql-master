-- Sample data for Part 107
SET search_path = school, public;

INSERT INTO schools (school_code, school_name) VALUES
('SUNRISE', 'Sunrise Public School');

INSERT INTO academic_years (school_id, year_code, starts_on, ends_on, status)
SELECT school_id, '2026-27', DATE '2026-04-01', DATE '2027-03-31', 'ACTIVE'
FROM schools WHERE school_code = 'SUNRISE';

INSERT INTO terms (academic_year_id, term_code, term_name, starts_on, ends_on)
SELECT academic_year_id, 'T1', 'Term 1', DATE '2026-04-01', DATE '2026-09-30'
FROM academic_years WHERE year_code = '2026-27';

INSERT INTO people (school_id, legal_name, preferred_name, date_of_birth, email_address, phone_e164)
SELECT school_id, v.legal_name, v.preferred_name, v.dob, v.email, v.phone
FROM schools s
CROSS JOIN (VALUES
 ('Aarav Sharma','Aarav',DATE '2013-07-12','aarav.student@example.test',NULL),
 ('Diya Patel','Diya',DATE '2013-11-03','diya.student@example.test',NULL),
 ('Meera Sharma','Meera',DATE '1986-02-18','meera.guardian@example.test','+919900000001'),
 ('Rohan Patel','Rohan',DATE '1982-09-09','rohan.guardian@example.test','+919900000002'),
 ('Kavita Rao','Kavita',DATE '1990-01-17','kavita.teacher@example.test','+919900000003')
) AS v(legal_name, preferred_name, dob, email, phone)
WHERE s.school_code = 'SUNRISE';

INSERT INTO students (school_id, person_id, admission_number, admitted_on)
SELECT p.school_id, p.person_id,
       CASE p.legal_name WHEN 'Aarav Sharma' THEN 'ADM-2026-001' ELSE 'ADM-2026-002' END,
       DATE '2026-04-01'
FROM people p WHERE p.legal_name IN ('Aarav Sharma','Diya Patel');

INSERT INTO guardians (school_id, person_id, occupation_text)
SELECT p.school_id, p.person_id, 'Professional'
FROM people p WHERE p.legal_name IN ('Meera Sharma','Rohan Patel');

INSERT INTO student_guardians (student_id, guardian_id, relationship_code, is_primary, receives_billing)
SELECT s.student_id, g.guardian_id, 'PARENT', TRUE, TRUE
FROM students s
JOIN people sp ON sp.person_id = s.person_id
JOIN people gp ON gp.legal_name = CASE sp.legal_name
    WHEN 'Aarav Sharma' THEN 'Meera Sharma' ELSE 'Rohan Patel' END
JOIN guardians g ON g.person_id = gp.person_id;

INSERT INTO teachers (school_id, person_id, employee_number)
SELECT p.school_id, p.person_id, 'EMP-1001'
FROM people p WHERE p.legal_name = 'Kavita Rao';

INSERT INTO subjects (school_id, subject_code, subject_name)
SELECT school_id, v.code, v.name FROM schools
CROSS JOIN (VALUES ('MATH','Mathematics'),('SCI','Science'),('ENG','English')) v(code,name)
WHERE school_code='SUNRISE';

INSERT INTO class_sections (academic_year_id, grade_code, section_code, capacity, homeroom_teacher_id)
SELECT ay.academic_year_id, 'GRADE-7', 'A', 40, t.teacher_id
FROM academic_years ay
JOIN teachers t ON t.school_id = ay.school_id
WHERE ay.year_code='2026-27';

INSERT INTO teaching_assignments (class_section_id, subject_id, teacher_id)
SELECT cs.class_section_id, sub.subject_id, t.teacher_id
FROM class_sections cs
JOIN academic_years ay ON ay.academic_year_id=cs.academic_year_id
JOIN subjects sub ON sub.school_id=ay.school_id
JOIN teachers t ON t.school_id=ay.school_id;

INSERT INTO enrollments (student_id, class_section_id, roll_number, enrolled_on)
SELECT s.student_id, cs.class_section_id,
       ROW_NUMBER() OVER (ORDER BY s.student_id), DATE '2026-04-01'
FROM students s
JOIN class_sections cs ON TRUE;

INSERT INTO fee_types (school_id, fee_code, fee_name)
SELECT school_id, v.code, v.name FROM schools
CROSS JOIN (VALUES ('TUITION','Tuition Fee'),('LAB','Laboratory Fee')) v(code,name);
