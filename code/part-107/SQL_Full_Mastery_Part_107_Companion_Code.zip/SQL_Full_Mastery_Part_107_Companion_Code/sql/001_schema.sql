-- SQL Full Mastery - Part 107
-- Student Management System Database
-- Primary target: PostgreSQL
-- Author: Ram Sandesh

BEGIN;

CREATE SCHEMA IF NOT EXISTS school;
SET search_path = school, public;

CREATE TABLE schools (
    school_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_code    VARCHAR(24) NOT NULL UNIQUE,
    school_name    VARCHAR(160) NOT NULL,
    timezone_name  VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE academic_years (
    academic_year_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id         BIGINT NOT NULL REFERENCES schools(school_id),
    year_code         VARCHAR(20) NOT NULL,
    starts_on         DATE NOT NULL,
    ends_on           DATE NOT NULL,
    status            VARCHAR(16) NOT NULL DEFAULT 'PLANNED'
                      CHECK (status IN ('PLANNED','ACTIVE','CLOSED')),
    CHECK (starts_on < ends_on),
    UNIQUE (school_id, year_code)
);

CREATE TABLE terms (
    term_id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    academic_year_id  BIGINT NOT NULL REFERENCES academic_years(academic_year_id),
    term_code         VARCHAR(20) NOT NULL,
    term_name         VARCHAR(80) NOT NULL,
    starts_on         DATE NOT NULL,
    ends_on           DATE NOT NULL,
    CHECK (starts_on <= ends_on),
    UNIQUE (academic_year_id, term_code)
);

CREATE TABLE people (
    person_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id       BIGINT NOT NULL REFERENCES schools(school_id),
    legal_name      VARCHAR(160) NOT NULL,
    preferred_name  VARCHAR(100),
    date_of_birth   DATE,
    email_address   VARCHAR(254),
    phone_e164      VARCHAR(20),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (school_id, email_address)
);

CREATE TABLE students (
    student_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id         BIGINT NOT NULL REFERENCES schools(school_id),
    person_id         BIGINT NOT NULL UNIQUE REFERENCES people(person_id),
    admission_number  VARCHAR(32) NOT NULL,
    admitted_on       DATE NOT NULL,
    status            VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                      CHECK (status IN ('APPLICANT','ACTIVE','SUSPENDED','ALUMNI','WITHDRAWN')),
    version_no        INTEGER NOT NULL DEFAULT 1 CHECK (version_no > 0),
    UNIQUE (school_id, admission_number)
);

CREATE TABLE guardians (
    guardian_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id        BIGINT NOT NULL REFERENCES schools(school_id),
    person_id        BIGINT NOT NULL UNIQUE REFERENCES people(person_id),
    occupation_text  VARCHAR(120)
);

CREATE TABLE student_guardians (
    student_id        BIGINT NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
    guardian_id       BIGINT NOT NULL REFERENCES guardians(guardian_id) ON DELETE CASCADE,
    relationship_code VARCHAR(24) NOT NULL,
    is_primary        BOOLEAN NOT NULL DEFAULT FALSE,
    may_collect       BOOLEAN NOT NULL DEFAULT TRUE,
    receives_billing  BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (student_id, guardian_id)
);

CREATE UNIQUE INDEX ux_student_primary_guardian
ON student_guardians (student_id)
WHERE is_primary;

CREATE TABLE teachers (
    teacher_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id        BIGINT NOT NULL REFERENCES schools(school_id),
    person_id        BIGINT NOT NULL UNIQUE REFERENCES people(person_id),
    employee_number  VARCHAR(32) NOT NULL,
    status           VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                     CHECK (status IN ('ACTIVE','LEAVE','INACTIVE')),
    UNIQUE (school_id, employee_number)
);

CREATE TABLE subjects (
    subject_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id     BIGINT NOT NULL REFERENCES schools(school_id),
    subject_code  VARCHAR(24) NOT NULL,
    subject_name  VARCHAR(100) NOT NULL,
    UNIQUE (school_id, subject_code)
);

CREATE TABLE class_sections (
    class_section_id  BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    academic_year_id  BIGINT NOT NULL REFERENCES academic_years(academic_year_id),
    grade_code        VARCHAR(20) NOT NULL,
    section_code      VARCHAR(20) NOT NULL,
    capacity          INTEGER NOT NULL CHECK (capacity > 0),
    homeroom_teacher_id BIGINT REFERENCES teachers(teacher_id),
    status            VARCHAR(16) NOT NULL DEFAULT 'OPEN'
                      CHECK (status IN ('OPEN','CLOSED','ARCHIVED')),
    UNIQUE (academic_year_id, grade_code, section_code)
);

CREATE TABLE teaching_assignments (
    class_section_id BIGINT NOT NULL REFERENCES class_sections(class_section_id) ON DELETE CASCADE,
    subject_id       BIGINT NOT NULL REFERENCES subjects(subject_id),
    teacher_id       BIGINT NOT NULL REFERENCES teachers(teacher_id),
    PRIMARY KEY (class_section_id, subject_id)
);

CREATE TABLE enrollments (
    enrollment_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    student_id       BIGINT NOT NULL REFERENCES students(student_id),
    class_section_id BIGINT NOT NULL REFERENCES class_sections(class_section_id),
    roll_number      INTEGER,
    enrolled_on      DATE NOT NULL,
    left_on          DATE,
    status           VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                     CHECK (status IN ('ACTIVE','COMPLETED','TRANSFERRED','WITHDRAWN')),
    CHECK (left_on IS NULL OR left_on >= enrolled_on),
    UNIQUE (student_id, class_section_id),
    UNIQUE (class_section_id, roll_number)
);

CREATE UNIQUE INDEX ux_one_active_enrollment_per_year
ON enrollments (student_id, class_section_id)
WHERE status = 'ACTIVE';

CREATE TABLE attendance_sessions (
    attendance_session_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    class_section_id       BIGINT NOT NULL REFERENCES class_sections(class_section_id),
    subject_id             BIGINT REFERENCES subjects(subject_id),
    attendance_date        DATE NOT NULL,
    period_no              SMALLINT,
    taken_by_teacher_id    BIGINT NOT NULL REFERENCES teachers(teacher_id),
    finalized_at           TIMESTAMPTZ,
    UNIQUE (class_section_id, subject_id, attendance_date, period_no)
);

CREATE TABLE attendance_records (
    attendance_session_id BIGINT NOT NULL REFERENCES attendance_sessions(attendance_session_id) ON DELETE CASCADE,
    enrollment_id         BIGINT NOT NULL REFERENCES enrollments(enrollment_id),
    attendance_status     VARCHAR(16) NOT NULL
                          CHECK (attendance_status IN ('PRESENT','ABSENT','LATE','EXCUSED')),
    minutes_late          SMALLINT NOT NULL DEFAULT 0 CHECK (minutes_late >= 0),
    note_text             VARCHAR(500),
    recorded_at           TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (attendance_session_id, enrollment_id)
);

CREATE TABLE assessments (
    assessment_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    term_id            BIGINT NOT NULL REFERENCES terms(term_id),
    class_section_id   BIGINT NOT NULL REFERENCES class_sections(class_section_id),
    subject_id         BIGINT NOT NULL REFERENCES subjects(subject_id),
    assessment_name    VARCHAR(120) NOT NULL,
    assessment_date    DATE NOT NULL,
    maximum_marks      NUMERIC(8,2) NOT NULL CHECK (maximum_marks > 0),
    weight_percent     NUMERIC(5,2) NOT NULL DEFAULT 0
                       CHECK (weight_percent >= 0 AND weight_percent <= 100),
    status             VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
                       CHECK (status IN ('DRAFT','PUBLISHED','LOCKED'))
);

CREATE TABLE assessment_scores (
    assessment_id BIGINT NOT NULL REFERENCES assessments(assessment_id) ON DELETE CASCADE,
    enrollment_id BIGINT NOT NULL REFERENCES enrollments(enrollment_id),
    marks_awarded NUMERIC(8,2),
    is_absent     BOOLEAN NOT NULL DEFAULT FALSE,
    feedback_text VARCHAR(1000),
    graded_at     TIMESTAMPTZ,
    CHECK ((is_absent AND marks_awarded IS NULL) OR
           (NOT is_absent AND marks_awarded IS NOT NULL AND marks_awarded >= 0)),
    PRIMARY KEY (assessment_id, enrollment_id)
);

CREATE TABLE fee_types (
    fee_type_id   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id     BIGINT NOT NULL REFERENCES schools(school_id),
    fee_code      VARCHAR(24) NOT NULL,
    fee_name      VARCHAR(100) NOT NULL,
    UNIQUE (school_id, fee_code)
);

CREATE TABLE fee_invoices (
    invoice_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id        BIGINT NOT NULL REFERENCES schools(school_id),
    student_id       BIGINT NOT NULL REFERENCES students(student_id),
    invoice_number   VARCHAR(40) NOT NULL,
    issued_on        DATE NOT NULL,
    due_on           DATE NOT NULL,
    status           VARCHAR(16) NOT NULL DEFAULT 'OPEN'
                     CHECK (status IN ('DRAFT','OPEN','PART_PAID','PAID','VOID')),
    total_paise      BIGINT NOT NULL DEFAULT 0 CHECK (total_paise >= 0),
    outstanding_paise BIGINT NOT NULL DEFAULT 0 CHECK (outstanding_paise >= 0),
    version_no       INTEGER NOT NULL DEFAULT 1 CHECK (version_no > 0),
    CHECK (due_on >= issued_on),
    CHECK (outstanding_paise <= total_paise),
    UNIQUE (school_id, invoice_number)
);

CREATE TABLE fee_invoice_lines (
    invoice_line_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    invoice_id      BIGINT NOT NULL REFERENCES fee_invoices(invoice_id) ON DELETE CASCADE,
    fee_type_id     BIGINT NOT NULL REFERENCES fee_types(fee_type_id),
    description     VARCHAR(200) NOT NULL,
    amount_paise    BIGINT NOT NULL CHECK (amount_paise >= 0)
);

CREATE TABLE payments (
    payment_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id         BIGINT NOT NULL REFERENCES schools(school_id),
    student_id        BIGINT NOT NULL REFERENCES students(student_id),
    receipt_number    VARCHAR(40) NOT NULL,
    paid_at           TIMESTAMPTZ NOT NULL,
    amount_paise      BIGINT NOT NULL CHECK (amount_paise > 0),
    payment_method    VARCHAR(24) NOT NULL,
    external_reference VARCHAR(100),
    status            VARCHAR(16) NOT NULL DEFAULT 'CONFIRMED'
                      CHECK (status IN ('PENDING','CONFIRMED','REVERSED')),
    UNIQUE (school_id, receipt_number)
);

CREATE TABLE payment_allocations (
    payment_id      BIGINT NOT NULL REFERENCES payments(payment_id),
    invoice_id      BIGINT NOT NULL REFERENCES fee_invoices(invoice_id),
    allocated_paise BIGINT NOT NULL CHECK (allocated_paise > 0),
    PRIMARY KEY (payment_id, invoice_id)
);

CREATE TABLE app_users (
    user_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id     BIGINT NOT NULL REFERENCES schools(school_id),
    username      VARCHAR(80) NOT NULL,
    password_hash TEXT NOT NULL,
    status        VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                  CHECK (status IN ('ACTIVE','LOCKED','DISABLED')),
    UNIQUE (school_id, username)
);

CREATE TABLE roles (
    role_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    role_code  VARCHAR(40) NOT NULL UNIQUE,
    role_name  VARCHAR(100) NOT NULL
);

CREATE TABLE user_roles (
    user_id BIGINT NOT NULL REFERENCES app_users(user_id) ON DELETE CASCADE,
    role_id BIGINT NOT NULL REFERENCES roles(role_id),
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE audit_events (
    audit_event_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id      BIGINT NOT NULL REFERENCES schools(school_id),
    actor_user_id  BIGINT REFERENCES app_users(user_id),
    event_type     VARCHAR(80) NOT NULL,
    entity_type    VARCHAR(80) NOT NULL,
    entity_id      VARCHAR(80) NOT NULL,
    occurred_at    TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    request_id     VARCHAR(100),
    before_json    JSONB,
    after_json     JSONB
);

CREATE TABLE outbox_events (
    outbox_event_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    school_id       BIGINT NOT NULL REFERENCES schools(school_id),
    aggregate_type  VARCHAR(80) NOT NULL,
    aggregate_id    VARCHAR(80) NOT NULL,
    event_type      VARCHAR(80) NOT NULL,
    payload_json    JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at    TIMESTAMPTZ
);

CREATE TABLE idempotency_keys (
    school_id       BIGINT NOT NULL REFERENCES schools(school_id),
    operation_code  VARCHAR(80) NOT NULL,
    idempotency_key VARCHAR(120) NOT NULL,
    request_hash    VARCHAR(128) NOT NULL,
    result_json     JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (school_id, operation_code, idempotency_key)
);

CREATE INDEX ix_people_school_name ON people (school_id, legal_name, person_id);
CREATE INDEX ix_enrollments_section_status ON enrollments (class_section_id, status, roll_number, enrollment_id);
CREATE INDEX ix_attendance_records_enrollment ON attendance_records (enrollment_id, attendance_session_id);
CREATE INDEX ix_attendance_sessions_date ON attendance_sessions (class_section_id, attendance_date DESC);
CREATE INDEX ix_assessments_class_subject_date ON assessments (class_section_id, subject_id, assessment_date DESC);
CREATE INDEX ix_scores_enrollment ON assessment_scores (enrollment_id, assessment_id);
CREATE INDEX ix_invoices_student_status_due ON fee_invoices (student_id, status, due_on, invoice_id);
CREATE INDEX ix_payments_student_paid ON payments (student_id, paid_at DESC, payment_id DESC);
CREATE INDEX ix_audit_entity ON audit_events (school_id, entity_type, entity_id, occurred_at DESC);
CREATE INDEX ix_outbox_unpublished ON outbox_events (created_at, outbox_event_id) WHERE published_at IS NULL;

COMMIT;
