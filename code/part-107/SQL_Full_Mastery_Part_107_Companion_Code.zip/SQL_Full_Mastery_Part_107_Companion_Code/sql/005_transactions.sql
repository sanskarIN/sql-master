-- Transaction patterns for Part 107
SET search_path = school, public;

-- Pattern A: capacity-safe enrollment (execute in one transaction)
BEGIN;
SELECT class_section_id, capacity
FROM class_sections
WHERE class_section_id = :class_section_id AND status = 'OPEN'
FOR UPDATE;

SELECT COUNT(*) AS active_count
FROM enrollments
WHERE class_section_id = :class_section_id AND status = 'ACTIVE';

-- Application verifies active_count < capacity, then inserts:
INSERT INTO enrollments (student_id, class_section_id, roll_number, enrolled_on)
VALUES (:student_id, :class_section_id, :roll_number, CURRENT_DATE);

INSERT INTO audit_events
(school_id, actor_user_id, event_type, entity_type, entity_id, after_json)
VALUES (:school_id, :actor_user_id, 'STUDENT_ENROLLED', 'enrollment',
        currval(pg_get_serial_sequence('school.enrollments','enrollment_id'))::text,
        jsonb_build_object('student_id', :student_id, 'class_section_id', :class_section_id));
COMMIT;

-- Pattern B: optimistic student update
UPDATE students
SET status = :new_status,
    version_no = version_no + 1
WHERE student_id = :student_id
  AND version_no = :expected_version;
-- Require exactly one affected row.

-- Pattern C: payment allocation (execute in one transaction)
BEGIN;
SELECT invoice_id, outstanding_paise
FROM fee_invoices
WHERE invoice_id = :invoice_id AND status IN ('OPEN','PART_PAID')
FOR UPDATE;

INSERT INTO payments
(school_id, student_id, receipt_number, paid_at, amount_paise, payment_method, external_reference)
VALUES (:school_id, :student_id, :receipt_number, CURRENT_TIMESTAMP,
        :amount_paise, :payment_method, :external_reference)
RETURNING payment_id;

INSERT INTO payment_allocations (payment_id, invoice_id, allocated_paise)
VALUES (:payment_id, :invoice_id, :amount_paise);

UPDATE fee_invoices
SET outstanding_paise = outstanding_paise - :amount_paise,
    status = CASE WHEN outstanding_paise - :amount_paise = 0 THEN 'PAID' ELSE 'PART_PAID' END,
    version_no = version_no + 1
WHERE invoice_id = :invoice_id
  AND outstanding_paise >= :amount_paise;
-- Require exactly one affected row.
COMMIT;
