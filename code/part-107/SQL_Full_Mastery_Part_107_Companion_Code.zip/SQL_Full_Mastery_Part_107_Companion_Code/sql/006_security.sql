-- Example PostgreSQL security model. Adapt role names to deployment.
SET search_path = school, public;

REVOKE ALL ON SCHEMA school FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA school FROM PUBLIC;

-- Roles are shown as documentation; creation normally belongs to infrastructure code.
-- CREATE ROLE school_app_login LOGIN PASSWORD 'managed-outside-source-control';
-- CREATE ROLE school_report_reader;
-- CREATE ROLE school_fee_writer;

-- GRANT USAGE ON SCHEMA school TO school_app_login, school_report_reader, school_fee_writer;
-- GRANT SELECT ON v_student_directory, v_attendance_summary, v_student_fee_balance TO school_report_reader;
-- GRANT SELECT, INSERT, UPDATE ON fee_invoices, fee_invoice_lines, payments, payment_allocations TO school_fee_writer;

ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE fee_invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY students_school_isolation ON students
USING (school_id = NULLIF(current_setting('app.school_id', true),'')::BIGINT)
WITH CHECK (school_id = NULLIF(current_setting('app.school_id', true),'')::BIGINT);

CREATE POLICY invoices_school_isolation ON fee_invoices
USING (school_id = NULLIF(current_setting('app.school_id', true),'')::BIGINT)
WITH CHECK (school_id = NULLIF(current_setting('app.school_id', true),'')::BIGINT);
