SET search_path = school, public;

-- 1. Deterministic class roster
SELECT d.admission_number, d.legal_name, d.roll_number
FROM v_student_directory d
WHERE d.grade_code = :grade_code AND d.section_code = :section_code
ORDER BY d.roll_number NULLS LAST, d.legal_name, d.student_id;

-- 2. Attendance below threshold
SELECT d.admission_number, d.legal_name, a.attendance_percent
FROM v_student_directory d
JOIN v_attendance_summary a ON a.student_id=d.student_id
WHERE a.attendance_percent < :minimum_percent
ORDER BY a.attendance_percent, d.legal_name, d.student_id;

-- 3. Subject performance with ranking
WITH score_percent AS (
  SELECT e.student_id, a.subject_id,
         SUM(sc.marks_awarded) AS earned,
         SUM(a.maximum_marks) AS possible
  FROM assessment_scores sc
  JOIN assessments a ON a.assessment_id=sc.assessment_id
  JOIN enrollments e ON e.enrollment_id=sc.enrollment_id
  WHERE a.term_id=:term_id AND NOT sc.is_absent
  GROUP BY e.student_id, a.subject_id
)
SELECT student_id, subject_id,
       ROUND(100.0*earned/NULLIF(possible,0),2) AS percentage,
       DENSE_RANK() OVER (PARTITION BY subject_id ORDER BY earned/NULLIF(possible,0) DESC) AS subject_rank
FROM score_percent
ORDER BY subject_id, subject_rank, student_id;

-- 4. Outstanding fee aging
SELECT fi.student_id, fi.invoice_number, fi.due_on, fi.outstanding_paise,
       CURRENT_DATE - fi.due_on AS days_overdue
FROM fee_invoices fi
WHERE fi.outstanding_paise > 0 AND fi.due_on < CURRENT_DATE
ORDER BY fi.due_on, fi.invoice_id;

-- 5. Primary guardian contacts
SELECT s.admission_number, sp.legal_name AS student_name,
       gp.legal_name AS guardian_name, gp.phone_e164, gp.email_address
FROM students s
JOIN people sp ON sp.person_id=s.person_id
JOIN student_guardians sg ON sg.student_id=s.student_id AND sg.is_primary
JOIN guardians g ON g.guardian_id=sg.guardian_id
JOIN people gp ON gp.person_id=g.person_id
ORDER BY sp.legal_name, s.student_id;
