# Production checklist

## Data model
- [ ] Every table has a documented grain and owner.
- [ ] Institution scope is included in natural uniqueness rules.
- [ ] Historical state is retained for enrollments, assessments, invoices, and payments.
- [ ] Currency uses integer paise and a documented currency code at system boundaries.

## Transactions
- [ ] Class capacity is protected with a lock or an equivalent serializable invariant.
- [ ] Payment allocation and invoice balance changes are atomic.
- [ ] Optimistic updates require an expected version and exactly one affected row.
- [ ] External messages are written through an outbox in the same transaction.

## Security and privacy
- [ ] Application accounts have least privilege.
- [ ] Institution isolation is tested for reads and writes.
- [ ] Guardian contacts, student birth dates, assessment details, and payment references are redacted in logs.
- [ ] Audit access is separately controlled and retention is documented.

## Operations
- [ ] Pool wait time, query latency, row counts, lock waits, deadlocks, and errors are monitored.
- [ ] Backup restore is rehearsed and timed.
- [ ] Migration rollback or forward-fix conditions are documented.
- [ ] Data-quality tests run after import and before publication.
