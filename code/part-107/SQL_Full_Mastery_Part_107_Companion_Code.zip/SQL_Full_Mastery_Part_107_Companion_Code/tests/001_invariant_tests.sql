-- Part 107 invariant tests
-- Run after schema and sample data. Each query should return zero rows unless noted.
SET search_path = school, public;

-- T1: no invoice has impossible balance
SELECT * FROM fee_invoices
WHERE outstanding_paise < 0 OR outstanding_paise > total_paise;

-- T2: no active class exceeds capacity
SELECT cs.class_section_id, cs.capacity, COUNT(*) AS active_students
FROM class_sections cs
JOIN enrollments e ON e.class_section_id=cs.class_section_id AND e.status='ACTIVE'
GROUP BY cs.class_section_id, cs.capacity
HAVING COUNT(*) > cs.capacity;

-- T3: no assessment score exceeds maximum marks
SELECT sc.*
FROM assessment_scores sc
JOIN assessments a ON a.assessment_id=sc.assessment_id
WHERE sc.marks_awarded > a.maximum_marks;

-- T4: payment allocations never exceed payment amount
SELECT p.payment_id, p.amount_paise, COALESCE(SUM(pa.allocated_paise),0) AS allocated
FROM payments p
LEFT JOIN payment_allocations pa ON pa.payment_id=p.payment_id
GROUP BY p.payment_id, p.amount_paise
HAVING COALESCE(SUM(pa.allocated_paise),0) > p.amount_paise;

-- T5: every active enrollment belongs to an active student
SELECT e.enrollment_id
FROM enrollments e
JOIN students s ON s.student_id=e.student_id
WHERE e.status='ACTIVE' AND s.status<>'ACTIVE';

-- T6: sample-data count (expected: 2)
SELECT COUNT(*) AS expected_two_students FROM students;
