# SQL Full Mastery - Part 107 Companion Project

## Student Management System Database

Author: **Ram Sandesh**  
Series: SQL Full Mastery, Part 107 of 120  
Open-source projects: https://www.github.com/sanskarIN  
Suggestions and project inquiries: sanskarin@outlook.in

This companion project provides a production-oriented PostgreSQL design for students, guardians, academic years, class sections, enrollments, attendance, assessments, fees, payments, roles, audit events, and transactional outbox events.

## Folder map

- `sql/001_schema.sql` - complete relational schema, constraints, and indexes
- `sql/002_seed.sql` - deterministic sample data
- `sql/003_views.sql` - directory, attendance, and fee-balance views
- `sql/004_reports.sql` - roster, attendance, performance, fee, and guardian reports
- `sql/005_transactions.sql` - enrollment, optimistic update, and payment patterns
- `sql/006_security.sql` - least privilege and row-level isolation examples
- `tests/001_invariant_tests.sql` - SQL assertions that should return zero defect rows
- `docs/production-checklist.md` - deployment and review checklist

## Recommended execution order

```text
psql -v ON_ERROR_STOP=1 -f sql/001_schema.sql
psql -v ON_ERROR_STOP=1 -f sql/002_seed.sql
psql -v ON_ERROR_STOP=1 -f sql/003_views.sql
psql -v ON_ERROR_STOP=1 -f tests/001_invariant_tests.sql
```

Supply connection details through standard PostgreSQL environment variables or your secret manager. Do not place production passwords in source control.

## Core correctness contracts

1. A student has one stable identity and an institution-scoped admission number.
2. Enrollment is capacity-safe and records history rather than overwriting it.
3. Attendance records are unique per session and enrollment.
4. An assessment score cannot exist without an assessment and enrollment.
5. Money is stored as integer paise; invoice balances never become negative.
6. Payment allocation, invoice balance update, audit event, and outbox event share one transaction where required.
7. Every list query has explicit projection, authorization, ordering, and row bounds.
8. Sensitive fields are protected by least privilege, row isolation, redaction, and audit evidence.
