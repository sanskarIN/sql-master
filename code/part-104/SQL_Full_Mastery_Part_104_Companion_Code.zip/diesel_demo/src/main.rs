use anyhow::{Context, Result};
use diesel::{
    connection::SimpleConnection,
    prelude::*,
    sql_query,
    sql_types::{BigInt, Text},
    sqlite::SqliteConnection,
};

#[derive(Debug, QueryableByName)]
struct NoteRow {
    #[diesel(sql_type = BigInt)]
    note_id: i64,
    #[diesel(sql_type = Text)]
    title: String,
    #[diesel(sql_type = BigInt)]
    version: i64,
}

fn main() -> Result<()> {
    let mut conn = SqliteConnection::establish("notes_diesel.db")
        .context("open Diesel SQLite connection")?;
    conn.batch_execute(
        "PRAGMA foreign_keys = ON;
         PRAGMA busy_timeout = 3000;
         PRAGMA journal_mode = WAL;
         CREATE TABLE IF NOT EXISTS notes(
           note_id INTEGER PRIMARY KEY,
           title TEXT NOT NULL,
           body TEXT NOT NULL DEFAULT '',
           version INTEGER NOT NULL DEFAULT 1,
           created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
           updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
         );",
    )?;

    let note_id = conn.transaction::<i64, diesel::result::Error, _>(|conn| {
        let inserted: NoteRow = sql_query(
            "INSERT INTO notes(title, body) VALUES(?1, ?2)
             RETURNING note_id, title, version",
        )
        .bind::<Text, _>("Diesel transaction boundary")
        .bind::<Text, _>("Typed binds and closure-scoped transaction ownership.")
        .get_result(conn)?;
        Ok(inserted.note_id)
    })?;

    let rows: Vec<NoteRow> = sql_query(
        "SELECT note_id, title, version
         FROM notes
         WHERE note_id >= ?1
         ORDER BY updated_at DESC, note_id DESC
         LIMIT 20",
    )
    .bind::<BigInt, _>(note_id)
    .load(&mut conn)?;

    for row in rows {
        println!("{} | {} | v{}", row.note_id, row.title, row.version);
    }
    Ok(())
}
