use anyhow::{Context, Result};
use sqlx::{sqlite::{SqliteConnectOptions, SqlitePoolOptions}, ConnectOptions, Row};
use std::{str::FromStr, time::Duration};
use uuid::Uuid;

#[tokio::main]
async fn main() -> Result<()> {
    let options = SqliteConnectOptions::from_str("sqlite://notes_sqlx.db")?
        .create_if_missing(true)
        .foreign_keys(true)
        .busy_timeout(Duration::from_secs(3))
        .journal_mode(sqlx::sqlite::SqliteJournalMode::Wal)
        .disable_statement_logging();

    let pool = SqlitePoolOptions::new()
        .max_connections(4)
        .acquire_timeout(Duration::from_secs(2))
        .connect_with(options)
        .await
        .context("connect SQLite pool")?;

    sqlx::migrate!().run(&pool).await.context("apply migrations")?;

    let mut tx = pool.begin().await?;
    let note_id: i64 = sqlx::query_scalar(
        "INSERT INTO notes(title, body) VALUES(?1, ?2) RETURNING note_id",
    )
    .bind("Async Rust database boundary")
    .bind("Bound work, explicit pool budgets, and one transaction owner.")
    .fetch_one(&mut *tx)
    .await?;

    sqlx::query(
        "INSERT INTO outbox(event_id, aggregate_id, event_type, payload_json)
         VALUES(?1, ?2, 'note.created', json_object('note_id', ?2))",
    )
    .bind(Uuid::new_v4().to_string())
    .bind(note_id)
    .execute(&mut *tx)
    .await?;
    tx.commit().await?;

    let rows = sqlx::query(
        "SELECT note_id, title, version
         FROM notes
         ORDER BY updated_at DESC, note_id DESC
         LIMIT ?1",
    )
    .bind(20_i64)
    .fetch_all(&pool)
    .await?;

    for row in rows {
        println!("{} | {} | v{}",
            row.get::<i64, _>("note_id"),
            row.get::<String, _>("title"),
            row.get::<i64, _>("version"));
    }

    pool.close().await;
    Ok(())
}
