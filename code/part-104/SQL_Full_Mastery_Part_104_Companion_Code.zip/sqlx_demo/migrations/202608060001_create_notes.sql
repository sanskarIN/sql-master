CREATE TABLE notes (
    note_id       INTEGER PRIMARY KEY,
    title         TEXT NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 120),
    body          TEXT NOT NULL DEFAULT '',
    version       INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE outbox (
    event_id      TEXT PRIMARY KEY,
    aggregate_id  INTEGER NOT NULL,
    event_type    TEXT NOT NULL,
    payload_json  TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at  TEXT
);

CREATE INDEX ix_notes_updated_note
    ON notes(updated_at DESC, note_id DESC);
