use anyhow::{Context, Result};
use rusqlite::{params, Connection, OptionalExtension, TransactionBehavior};
use uuid::Uuid;

fn migrate(conn: &Connection) -> Result<()> {
    let version: i64 = conn.query_row("PRAGMA user_version", [], |row| row.get(0))?;
    if version < 1 {
        conn.execute_batch(
            "BEGIN IMMEDIATE;
             CREATE TABLE notes(
               note_id INTEGER PRIMARY KEY,
               title TEXT NOT NULL CHECK(length(trim(title)) BETWEEN 1 AND 120),
               body TEXT NOT NULL DEFAULT '',
               version INTEGER NOT NULL DEFAULT 1,
               created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
               updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
             );
             CREATE TABLE outbox(
               event_id TEXT PRIMARY KEY,
               aggregate_id INTEGER NOT NULL,
               event_type TEXT NOT NULL,
               payload_json TEXT NOT NULL,
               created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
               published_at TEXT
             );
             CREATE INDEX ix_notes_updated_note
               ON notes(updated_at DESC, note_id DESC);
             PRAGMA user_version = 1;
             COMMIT;",
        )?;
    }
    Ok(())
}

fn create_note(conn: &mut Connection, title: &str, body: &str) -> Result<i64> {
    let tx = conn.transaction_with_behavior(TransactionBehavior::Immediate)?;
    let note_id: i64 = tx.query_row(
        "INSERT INTO notes(title, body) VALUES(?1, ?2) RETURNING note_id",
        params![title, body],
        |row| row.get(0),
    )?;
    let event_id = Uuid::new_v4().to_string();
    tx.execute(
        "INSERT INTO outbox(event_id, aggregate_id, event_type, payload_json)
         VALUES(?1, ?2, 'note.created', json_object('note_id', ?2, 'title', ?3))",
        params![event_id, note_id, title],
    )?;
    tx.commit()?;
    Ok(note_id)
}

fn rename_note(conn: &Connection, note_id: i64, expected_version: i64, title: &str) -> Result<bool> {
    let changed = conn.execute(
        "UPDATE notes
         SET title = ?1, version = version + 1, updated_at = CURRENT_TIMESTAMP
         WHERE note_id = ?2 AND version = ?3",
        params![title, note_id, expected_version],
    )?;
    Ok(changed == 1)
}

fn main() -> Result<()> {
    let mut conn = Connection::open("notes_rusqlite.db").context("open SQLite database")?;
    conn.busy_timeout(std::time::Duration::from_secs(3))?;
    conn.execute_batch("PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;")?;
    migrate(&conn)?;

    let note_id = create_note(
        &mut conn,
        "Rust ownership at the data boundary",
        "Bind values, keep transactions short, and retain recovery evidence.",
    )?;

    let row: Option<(String, i64)> = conn
        .query_row(
            "SELECT title, version FROM notes WHERE note_id = ?1",
            [note_id],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .optional()?;

    if let Some((title, version)) = row {
        println!("{note_id} | {title} | v{version}");
        let updated = rename_note(&conn, note_id, version, "Rust-safe SQLite note")?;
        println!("optimistic update applied: {updated}");
    }
    Ok(())
}
