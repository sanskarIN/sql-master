PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS notes (
    note_id       INTEGER PRIMARY KEY,
    title         TEXT NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 120),
    body          TEXT NOT NULL DEFAULT '',
    version       INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS outbox (
    event_id      TEXT PRIMARY KEY,
    aggregate_id  INTEGER NOT NULL,
    event_type    TEXT NOT NULL,
    payload_json  TEXT NOT NULL,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at  TEXT
);

CREATE INDEX IF NOT EXISTS ix_notes_updated_note
    ON notes(updated_at DESC, note_id DESC);

CREATE INDEX IF NOT EXISTS ix_outbox_unpublished
    ON outbox(created_at, event_id)
    WHERE published_at IS NULL;
