-- Read models and operational views
SET search_path = commerce, public;

CREATE OR REPLACE VIEW v_catalog_offer AS
SELECT s.store_id, p.product_id, p.product_code, p.product_name,
       v.variant_id, v.sku, v.variant_name,
       pb.currency_code, vp.unit_price_paise, vp.compare_at_paise,
       COALESCE(SUM(ib.on_hand_qty - ib.reserved_qty), 0) AS available_qty
FROM stores s
JOIN products p ON p.store_id=s.store_id AND p.status='ACTIVE'
JOIN product_variants v ON v.product_id=p.product_id AND v.is_active
JOIN variant_prices vp ON vp.variant_id=v.variant_id
JOIN price_books pb ON pb.price_book_id=vp.price_book_id
    AND pb.store_id=s.store_id AND pb.status='ACTIVE'
    AND CURRENT_TIMESTAMP >= pb.starts_at
    AND (pb.ends_at IS NULL OR CURRENT_TIMESTAMP < pb.ends_at)
LEFT JOIN inventory_balances ib ON ib.variant_id=v.variant_id
GROUP BY s.store_id, p.product_id, p.product_code, p.product_name,
         v.variant_id, v.sku, v.variant_name,
         pb.currency_code, vp.unit_price_paise, vp.compare_at_paise;

CREATE OR REPLACE VIEW v_order_financial_position AS
SELECT o.order_id, o.store_id, o.order_number, o.status, o.currency_code,
       o.grand_total_paise, o.paid_total_paise, o.refunded_total_paise,
       o.paid_total_paise - o.refunded_total_paise AS net_captured_paise,
       o.grand_total_paise - o.paid_total_paise AS unpaid_paise
FROM orders o;

CREATE OR REPLACE VIEW v_order_fulfilment AS
SELECT o.order_id, o.order_number, o.status,
       SUM(ol.quantity) AS ordered_qty,
       COALESCE(SUM(sl.quantity), 0) AS shipped_qty,
       SUM(ol.quantity) - COALESCE(SUM(sl.quantity), 0) AS remaining_qty
FROM orders o
JOIN order_lines ol ON ol.order_id=o.order_id
LEFT JOIN shipment_lines sl ON sl.order_line_id=ol.order_line_id
GROUP BY o.order_id, o.order_number, o.status;
