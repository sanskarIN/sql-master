-- SQL Full Mastery - Part 108
-- E-Commerce Database and Order Workflow
-- Primary target: PostgreSQL 15+
-- Author: Ram Sandesh

BEGIN;
CREATE SCHEMA IF NOT EXISTS commerce;
SET search_path = commerce, public;

CREATE TABLE stores (
    store_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_code      VARCHAR(24) NOT NULL UNIQUE,
    store_name      VARCHAR(160) NOT NULL,
    currency_code   CHAR(3) NOT NULL DEFAULT 'INR',
    timezone_name   VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE customers (
    customer_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id         BIGINT NOT NULL REFERENCES stores(store_id),
    customer_number  VARCHAR(32) NOT NULL,
    email_address    VARCHAR(254),
    display_name     VARCHAR(160) NOT NULL,
    status           VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                     CHECK (status IN ('ACTIVE','BLOCKED','DELETED')),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (store_id, customer_number),
    UNIQUE (store_id, email_address)
);

CREATE TABLE customer_addresses (
    address_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id      BIGINT NOT NULL REFERENCES customers(customer_id) ON DELETE CASCADE,
    address_type     VARCHAR(16) NOT NULL CHECK (address_type IN ('SHIPPING','BILLING','OTHER')),
    recipient_name   VARCHAR(160) NOT NULL,
    line1            VARCHAR(200) NOT NULL,
    line2            VARCHAR(200),
    city_name        VARCHAR(100) NOT NULL,
    region_name      VARCHAR(100),
    postal_code      VARCHAR(20) NOT NULL,
    country_code     CHAR(2) NOT NULL,
    phone_e164       VARCHAR(20),
    is_default       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX ux_default_customer_address
ON customer_addresses (customer_id, address_type)
WHERE is_default;

CREATE TABLE products (
    product_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id         BIGINT NOT NULL REFERENCES stores(store_id),
    product_code     VARCHAR(40) NOT NULL,
    product_name     VARCHAR(200) NOT NULL,
    description_text TEXT,
    status           VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
                     CHECK (status IN ('DRAFT','ACTIVE','ARCHIVED')),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (store_id, product_code)
);

CREATE TABLE product_variants (
    variant_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    product_id       BIGINT NOT NULL REFERENCES products(product_id),
    sku              VARCHAR(64) NOT NULL,
    variant_name     VARCHAR(160) NOT NULL,
    barcode          VARCHAR(64),
    weight_grams     INTEGER CHECK (weight_grams IS NULL OR weight_grams >= 0),
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    version_no       INTEGER NOT NULL DEFAULT 1 CHECK (version_no > 0),
    UNIQUE (sku),
    UNIQUE (barcode)
);

CREATE TABLE price_books (
    price_book_id    BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id         BIGINT NOT NULL REFERENCES stores(store_id),
    price_book_code  VARCHAR(32) NOT NULL,
    currency_code    CHAR(3) NOT NULL,
    starts_at        TIMESTAMPTZ NOT NULL,
    ends_at          TIMESTAMPTZ,
    status           VARCHAR(16) NOT NULL DEFAULT 'DRAFT'
                     CHECK (status IN ('DRAFT','ACTIVE','RETIRED')),
    CHECK (ends_at IS NULL OR ends_at > starts_at),
    UNIQUE (store_id, price_book_code)
);

CREATE TABLE variant_prices (
    price_book_id    BIGINT NOT NULL REFERENCES price_books(price_book_id) ON DELETE CASCADE,
    variant_id       BIGINT NOT NULL REFERENCES product_variants(variant_id),
    unit_price_paise BIGINT NOT NULL CHECK (unit_price_paise >= 0),
    compare_at_paise BIGINT CHECK (compare_at_paise IS NULL OR compare_at_paise >= unit_price_paise),
    PRIMARY KEY (price_book_id, variant_id)
);

CREATE TABLE inventory_locations (
    location_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id         BIGINT NOT NULL REFERENCES stores(store_id),
    location_code    VARCHAR(32) NOT NULL,
    location_name    VARCHAR(120) NOT NULL,
    status           VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                     CHECK (status IN ('ACTIVE','INACTIVE')),
    UNIQUE (store_id, location_code)
);

CREATE TABLE inventory_balances (
    location_id      BIGINT NOT NULL REFERENCES inventory_locations(location_id),
    variant_id       BIGINT NOT NULL REFERENCES product_variants(variant_id),
    on_hand_qty      INTEGER NOT NULL DEFAULT 0 CHECK (on_hand_qty >= 0),
    reserved_qty     INTEGER NOT NULL DEFAULT 0 CHECK (reserved_qty >= 0),
    version_no       INTEGER NOT NULL DEFAULT 1 CHECK (version_no > 0),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CHECK (reserved_qty <= on_hand_qty),
    PRIMARY KEY (location_id, variant_id)
);

CREATE TABLE carts (
    cart_id          UUID PRIMARY KEY,
    store_id         BIGINT NOT NULL REFERENCES stores(store_id),
    customer_id      BIGINT REFERENCES customers(customer_id),
    status           VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                     CHECK (status IN ('ACTIVE','CONVERTED','ABANDONED','EXPIRED')),
    currency_code    CHAR(3) NOT NULL,
    expires_at       TIMESTAMPTZ,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cart_items (
    cart_id          UUID NOT NULL REFERENCES carts(cart_id) ON DELETE CASCADE,
    variant_id       BIGINT NOT NULL REFERENCES product_variants(variant_id),
    quantity         INTEGER NOT NULL CHECK (quantity > 0),
    added_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (cart_id, variant_id)
);

CREATE TABLE orders (
    order_id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id                 BIGINT NOT NULL REFERENCES stores(store_id),
    customer_id              BIGINT REFERENCES customers(customer_id),
    order_number             VARCHAR(40) NOT NULL,
    status                   VARCHAR(20) NOT NULL DEFAULT 'PENDING_PAYMENT'
                             CHECK (status IN ('PENDING_PAYMENT','PAID','ALLOCATED','PART_SHIPPED','SHIPPED','COMPLETED','CANCELLED')),
    currency_code            CHAR(3) NOT NULL,
    item_subtotal_paise      BIGINT NOT NULL CHECK (item_subtotal_paise >= 0),
    discount_total_paise     BIGINT NOT NULL DEFAULT 0 CHECK (discount_total_paise >= 0),
    shipping_total_paise     BIGINT NOT NULL DEFAULT 0 CHECK (shipping_total_paise >= 0),
    tax_total_paise          BIGINT NOT NULL DEFAULT 0 CHECK (tax_total_paise >= 0),
    grand_total_paise        BIGINT NOT NULL CHECK (grand_total_paise >= 0),
    paid_total_paise         BIGINT NOT NULL DEFAULT 0 CHECK (paid_total_paise >= 0),
    refunded_total_paise     BIGINT NOT NULL DEFAULT 0 CHECK (refunded_total_paise >= 0),
    shipping_address_json    JSONB NOT NULL,
    billing_address_json     JSONB NOT NULL,
    placed_at                TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version_no               INTEGER NOT NULL DEFAULT 1 CHECK (version_no > 0),
    CHECK (grand_total_paise = item_subtotal_paise - discount_total_paise + shipping_total_paise + tax_total_paise),
    CHECK (paid_total_paise <= grand_total_paise),
    CHECK (refunded_total_paise <= paid_total_paise),
    UNIQUE (store_id, order_number)
);

CREATE TABLE order_lines (
    order_line_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id           BIGINT NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
    variant_id         BIGINT REFERENCES product_variants(variant_id),
    sku_snapshot       VARCHAR(64) NOT NULL,
    product_name_snapshot VARCHAR(200) NOT NULL,
    variant_name_snapshot VARCHAR(160) NOT NULL,
    quantity           INTEGER NOT NULL CHECK (quantity > 0),
    unit_price_paise   BIGINT NOT NULL CHECK (unit_price_paise >= 0),
    discount_paise     BIGINT NOT NULL DEFAULT 0 CHECK (discount_paise >= 0),
    tax_paise          BIGINT NOT NULL DEFAULT 0 CHECK (tax_paise >= 0),
    line_total_paise   BIGINT NOT NULL CHECK (line_total_paise >= 0),
    CHECK (line_total_paise = quantity * unit_price_paise - discount_paise + tax_paise)
);

CREATE TABLE promotions (
    promotion_id      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id          BIGINT NOT NULL REFERENCES stores(store_id),
    promotion_code    VARCHAR(40) NOT NULL,
    promotion_name    VARCHAR(160) NOT NULL,
    discount_type     VARCHAR(16) NOT NULL CHECK (discount_type IN ('FIXED','PERCENT')),
    discount_value    INTEGER NOT NULL CHECK (discount_value > 0),
    minimum_paise     BIGINT NOT NULL DEFAULT 0 CHECK (minimum_paise >= 0),
    starts_at         TIMESTAMPTZ NOT NULL,
    ends_at           TIMESTAMPTZ NOT NULL,
    usage_limit       INTEGER CHECK (usage_limit IS NULL OR usage_limit > 0),
    status            VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                      CHECK (status IN ('DRAFT','ACTIVE','PAUSED','EXPIRED')),
    CHECK (ends_at > starts_at),
    UNIQUE (store_id, promotion_code)
);

CREATE TABLE order_promotions (
    order_id          BIGINT NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
    promotion_id      BIGINT NOT NULL REFERENCES promotions(promotion_id),
    code_snapshot     VARCHAR(40) NOT NULL,
    discount_paise    BIGINT NOT NULL CHECK (discount_paise >= 0),
    PRIMARY KEY (order_id, promotion_id)
);

CREATE TABLE inventory_reservations (
    reservation_id   BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id         BIGINT NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
    order_line_id    BIGINT NOT NULL REFERENCES order_lines(order_line_id) ON DELETE CASCADE,
    location_id      BIGINT NOT NULL REFERENCES inventory_locations(location_id),
    variant_id       BIGINT NOT NULL REFERENCES product_variants(variant_id),
    quantity         INTEGER NOT NULL CHECK (quantity > 0),
    status           VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
                     CHECK (status IN ('ACTIVE','RELEASED','CONSUMED','EXPIRED')),
    expires_at       TIMESTAMPTZ,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (order_line_id, location_id, status)
);

CREATE TABLE payment_attempts (
    payment_id        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id          BIGINT NOT NULL REFERENCES orders(order_id),
    provider_code     VARCHAR(32) NOT NULL,
    provider_payment_ref VARCHAR(120),
    idempotency_key   VARCHAR(120) NOT NULL,
    amount_paise      BIGINT NOT NULL CHECK (amount_paise > 0),
    status            VARCHAR(20) NOT NULL DEFAULT 'CREATED'
                      CHECK (status IN ('CREATED','AUTHORIZED','CAPTURED','FAILED','CANCELLED')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (provider_code, idempotency_key),
    UNIQUE (provider_code, provider_payment_ref)
);

CREATE TABLE refunds (
    refund_id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    payment_id        BIGINT NOT NULL REFERENCES payment_attempts(payment_id),
    provider_refund_ref VARCHAR(120),
    idempotency_key   VARCHAR(120) NOT NULL,
    amount_paise      BIGINT NOT NULL CHECK (amount_paise > 0),
    reason_code       VARCHAR(40) NOT NULL,
    status            VARCHAR(20) NOT NULL DEFAULT 'REQUESTED'
                      CHECK (status IN ('REQUESTED','SUCCEEDED','FAILED','CANCELLED')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (payment_id, idempotency_key),
    UNIQUE (provider_refund_ref)
);

CREATE TABLE shipments (
    shipment_id       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id          BIGINT NOT NULL REFERENCES orders(order_id),
    location_id       BIGINT NOT NULL REFERENCES inventory_locations(location_id),
    shipment_number   VARCHAR(48) NOT NULL UNIQUE,
    carrier_code      VARCHAR(32),
    tracking_number   VARCHAR(100),
    status            VARCHAR(20) NOT NULL DEFAULT 'PENDING'
                      CHECK (status IN ('PENDING','PACKED','SHIPPED','DELIVERED','LOST','CANCELLED')),
    shipped_at        TIMESTAMPTZ,
    delivered_at      TIMESTAMPTZ,
    CHECK (delivered_at IS NULL OR shipped_at IS NOT NULL)
);

CREATE TABLE shipment_lines (
    shipment_id       BIGINT NOT NULL REFERENCES shipments(shipment_id) ON DELETE CASCADE,
    order_line_id     BIGINT NOT NULL REFERENCES order_lines(order_line_id),
    quantity          INTEGER NOT NULL CHECK (quantity > 0),
    PRIMARY KEY (shipment_id, order_line_id)
);

CREATE TABLE idempotency_records (
    store_id          BIGINT NOT NULL REFERENCES stores(store_id),
    operation_code    VARCHAR(48) NOT NULL,
    idempotency_key   VARCHAR(120) NOT NULL,
    request_hash      CHAR(64) NOT NULL,
    status            VARCHAR(16) NOT NULL CHECK (status IN ('IN_PROGRESS','SUCCEEDED','FAILED')),
    result_json       JSONB,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at        TIMESTAMPTZ,
    PRIMARY KEY (store_id, operation_code, idempotency_key)
);

CREATE TABLE outbox_events (
    event_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id          BIGINT NOT NULL REFERENCES stores(store_id),
    aggregate_type    VARCHAR(48) NOT NULL,
    aggregate_id      VARCHAR(80) NOT NULL,
    event_type        VARCHAR(80) NOT NULL,
    payload_json      JSONB NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at      TIMESTAMPTZ,
    attempt_count     INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0)
);

CREATE TABLE audit_events (
    audit_id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    store_id          BIGINT NOT NULL REFERENCES stores(store_id),
    actor_type        VARCHAR(24) NOT NULL,
    actor_id          VARCHAR(80),
    action_code       VARCHAR(64) NOT NULL,
    entity_type       VARCHAR(48) NOT NULL,
    entity_id         VARCHAR(80) NOT NULL,
    request_id        VARCHAR(80),
    detail_json       JSONB NOT NULL DEFAULT '{}'::jsonb,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX ix_products_active ON products (store_id, status, product_id);
CREATE INDEX ix_variants_product_active ON product_variants (product_id, is_active, variant_id);
CREATE INDEX ix_prices_lookup ON variant_prices (variant_id, price_book_id);
CREATE INDEX ix_inventory_available ON inventory_balances (variant_id, location_id)
    INCLUDE (on_hand_qty, reserved_qty, version_no);
CREATE INDEX ix_orders_customer_history ON orders (store_id, customer_id, placed_at DESC, order_id DESC);
CREATE INDEX ix_orders_status_queue ON orders (store_id, status, placed_at, order_id);
CREATE INDEX ix_reservations_expiry ON inventory_reservations (status, expires_at)
    WHERE status = 'ACTIVE';
CREATE INDEX ix_payments_order ON payment_attempts (order_id, created_at DESC);
CREATE INDEX ix_shipments_order ON shipments (order_id, shipment_id);
CREATE INDEX ix_outbox_unpublished ON outbox_events (created_at, event_id)
    WHERE published_at IS NULL;
CREATE INDEX ix_audit_entity ON audit_events (store_id, entity_type, entity_id, occurred_at DESC);

COMMIT;
