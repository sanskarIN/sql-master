-- Production workflow patterns. Bind all values through the driver.
SET search_path = commerce, public;

-- A. Capacity-safe inventory reservation for one line.
BEGIN;
SELECT on_hand_qty, reserved_qty, version_no
FROM inventory_balances
WHERE location_id = :location_id AND variant_id = :variant_id
FOR UPDATE;

-- Application verifies on_hand_qty - reserved_qty >= :quantity.
UPDATE inventory_balances
SET reserved_qty = reserved_qty + :quantity,
    version_no = version_no + 1,
    updated_at = CURRENT_TIMESTAMP
WHERE location_id = :location_id
  AND variant_id = :variant_id
  AND on_hand_qty - reserved_qty >= :quantity;
-- Application asserts exactly one updated row.

INSERT INTO inventory_reservations
(order_id, order_line_id, location_id, variant_id, quantity, status, expires_at)
VALUES (:order_id, :order_line_id, :location_id, :variant_id, :quantity,
        'ACTIVE', CURRENT_TIMESTAMP + INTERVAL '20 minutes');
COMMIT;

-- B. Optimistic order-state transition.
UPDATE orders
SET status = :next_status,
    version_no = version_no + 1
WHERE order_id = :order_id
  AND version_no = :expected_version
  AND status = :expected_status;
-- Application asserts exactly one updated row.

-- C. Capture confirmation and outbox event share one transaction.
BEGIN;
UPDATE payment_attempts
SET status='CAPTURED', provider_payment_ref=:provider_ref, updated_at=CURRENT_TIMESTAMP
WHERE payment_id=:payment_id AND status IN ('CREATED','AUTHORIZED');

UPDATE orders
SET paid_total_paise = paid_total_paise + :captured_paise,
    status = CASE WHEN paid_total_paise + :captured_paise = grand_total_paise THEN 'PAID' ELSE status END,
    version_no = version_no + 1
WHERE order_id=:order_id
  AND paid_total_paise + :captured_paise <= grand_total_paise;

INSERT INTO outbox_events
(store_id, aggregate_type, aggregate_id, event_type, payload_json)
VALUES (:store_id, 'order', CAST(:order_id AS VARCHAR), 'PAYMENT_CAPTURED',
        jsonb_build_object('order_id', :order_id,
                           'payment_id', :payment_id,
                           'amount_paise', :captured_paise));
COMMIT;

-- D. Refund with locked financial position.
BEGIN;
SELECT paid_total_paise, refunded_total_paise
FROM orders WHERE order_id=:order_id FOR UPDATE;
-- Verify refundable amount before inserting.
INSERT INTO refunds (payment_id, provider_refund_ref, idempotency_key, amount_paise, reason_code, status)
VALUES (:payment_id, :provider_refund_ref, :idempotency_key, :refund_paise, :reason_code, 'SUCCEEDED');
UPDATE orders
SET refunded_total_paise = refunded_total_paise + :refund_paise,
    version_no = version_no + 1
WHERE order_id=:order_id
  AND refunded_total_paise + :refund_paise <= paid_total_paise;
COMMIT;
