-- Bounded, deterministic operational and analytical queries
SET search_path = commerce, public;

-- Customer order history: keyset pagination.
SELECT order_id, order_number, status, currency_code, grand_total_paise, placed_at
FROM orders
WHERE store_id=:store_id
  AND customer_id=:customer_id
  AND (placed_at, order_id) < (:cursor_time, :cursor_id)
ORDER BY placed_at DESC, order_id DESC
LIMIT :page_size;

-- Orders awaiting fulfilment.
SELECT order_id, order_number, placed_at, grand_total_paise
FROM orders
WHERE store_id=:store_id AND status IN ('PAID','ALLOCATED','PART_SHIPPED')
ORDER BY placed_at, order_id
LIMIT :queue_limit;

-- Reservation expiry queue with SKIP LOCKED.
SELECT reservation_id
FROM inventory_reservations
WHERE status='ACTIVE' AND expires_at < CURRENT_TIMESTAMP
ORDER BY expires_at, reservation_id
FOR UPDATE SKIP LOCKED
LIMIT :batch_size;

-- Daily commerce summary without mixing order-line grain.
WITH order_day AS (
  SELECT store_id, placed_at::date AS order_date,
         COUNT(*) AS order_count,
         SUM(grand_total_paise) AS booked_paise,
         SUM(paid_total_paise) AS captured_paise,
         SUM(refunded_total_paise) AS refunded_paise
  FROM orders
  WHERE placed_at >= :from_time AND placed_at < :to_time
  GROUP BY store_id, placed_at::date
)
SELECT * FROM order_day ORDER BY store_id, order_date;

-- Best-selling variants based on order-line grain.
SELECT ol.variant_id, ol.sku_snapshot,
       SUM(ol.quantity) AS units,
       SUM(ol.line_total_paise) AS gross_line_paise
FROM order_lines ol
JOIN orders o ON o.order_id=ol.order_id
WHERE o.store_id=:store_id
  AND o.placed_at >= :from_time AND o.placed_at < :to_time
  AND o.status <> 'CANCELLED'
GROUP BY ol.variant_id, ol.sku_snapshot
ORDER BY units DESC, ol.variant_id
LIMIT :top_n;
