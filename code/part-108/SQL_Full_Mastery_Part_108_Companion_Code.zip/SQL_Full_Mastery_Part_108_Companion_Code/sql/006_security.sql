-- Example least-privilege roles. Review before production use.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='commerce_app') THEN
    CREATE ROLE commerce_app NOLOGIN;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='commerce_report') THEN
    CREATE ROLE commerce_report NOLOGIN;
  END IF;
END $$;

GRANT USAGE ON SCHEMA commerce TO commerce_app, commerce_report;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA commerce TO commerce_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA commerce TO commerce_app;
GRANT SELECT ON commerce.v_catalog_offer,
                commerce.v_order_financial_position,
                commerce.v_order_fulfilment TO commerce_report;
REVOKE ALL ON commerce.idempotency_records, commerce.audit_events FROM commerce_report;

-- Production applications should use separate roles for checkout, fulfilment,
-- reporting, and support tools, with row/tenant predicates tested explicitly.
