-- Deterministic sample data for Part 108
SET search_path = commerce, public;

INSERT INTO stores (store_code, store_name) VALUES ('MAIN-IN', 'Mastery Commerce India');

INSERT INTO customers (store_id, customer_number, email_address, display_name)
SELECT store_id, 'CUS-1001', 'anaya@example.test', 'Anaya Gupta' FROM stores WHERE store_code='MAIN-IN';

INSERT INTO customer_addresses
(customer_id, address_type, recipient_name, line1, city_name, region_name, postal_code, country_code, phone_e164, is_default)
SELECT customer_id, 'SHIPPING', 'Anaya Gupta', '18 Knowledge Lane', 'Lucknow', 'Uttar Pradesh', '226001', 'IN', '+919999000001', TRUE
FROM customers WHERE customer_number='CUS-1001';

INSERT INTO products (store_id, product_code, product_name, status)
SELECT store_id, 'SQL-BOOK', 'SQL Full Mastery Printed Edition', 'ACTIVE' FROM stores WHERE store_code='MAIN-IN';
INSERT INTO products (store_id, product_code, product_name, status)
SELECT store_id, 'DB-WORKBOOK', 'Database Design Workbook', 'ACTIVE' FROM stores WHERE store_code='MAIN-IN';

INSERT INTO product_variants (product_id, sku, variant_name, weight_grams)
SELECT product_id, 'SQL-BOOK-PB', 'Paperback', 740 FROM products WHERE product_code='SQL-BOOK';
INSERT INTO product_variants (product_id, sku, variant_name, weight_grams)
SELECT product_id, 'DB-WORKBOOK-PB', 'Paperback', 520 FROM products WHERE product_code='DB-WORKBOOK';

INSERT INTO price_books (store_id, price_book_code, currency_code, starts_at, status)
SELECT store_id, 'INR-RETAIL-2026', 'INR', TIMESTAMPTZ '2026-08-01 00:00:00+05:30', 'ACTIVE'
FROM stores WHERE store_code='MAIN-IN';

INSERT INTO variant_prices (price_book_id, variant_id, unit_price_paise, compare_at_paise)
SELECT pb.price_book_id, v.variant_id,
       CASE v.sku WHEN 'SQL-BOOK-PB' THEN 24900 ELSE 19900 END,
       CASE v.sku WHEN 'SQL-BOOK-PB' THEN 39900 ELSE 29900 END
FROM price_books pb CROSS JOIN product_variants v
WHERE pb.price_book_code='INR-RETAIL-2026';

INSERT INTO inventory_locations (store_id, location_code, location_name)
SELECT store_id, 'LKO-01', 'Lucknow Fulfilment Centre' FROM stores WHERE store_code='MAIN-IN';

INSERT INTO inventory_balances (location_id, variant_id, on_hand_qty, reserved_qty)
SELECT l.location_id, v.variant_id,
       CASE v.sku WHEN 'SQL-BOOK-PB' THEN 40 ELSE 25 END, 0
FROM inventory_locations l CROSS JOIN product_variants v
WHERE l.location_code='LKO-01';

INSERT INTO promotions
(store_id, promotion_code, promotion_name, discount_type, discount_value, minimum_paise, starts_at, ends_at, usage_limit)
SELECT store_id, 'AUGUST10', 'August Launch 10 Percent', 'PERCENT', 10, 30000,
       TIMESTAMPTZ '2026-08-01 00:00:00+05:30', TIMESTAMPTZ '2026-09-01 00:00:00+05:30', 10000
FROM stores WHERE store_code='MAIN-IN';
