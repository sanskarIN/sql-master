# SQL Full Mastery - Part 108 Companion Project

## E-Commerce Database and Order Workflow

Author: **Ram Sandesh**  
Series: SQL Full Mastery, Part 108 of 120  
Open-source projects: https://www.github.com/sanskarIN  
Suggestions and project inquiries: sanskarin@outlook.in

This package demonstrates a production-oriented PostgreSQL design for catalog items, variants, prices, customers, address snapshots, carts, orders, order lines, inventory reservations, payments, refunds, shipments, promotions, idempotency, audit history, outbox events, reports, and operational tests.

## Files

- `sql/001_schema.sql` - schema, constraints, indexes, and lifecycle states
- `sql/002_seed.sql` - deterministic catalog and inventory seed data
- `sql/003_views.sql` - catalog, financial, and fulfilment read models
- `sql/004_workflows.sql` - reservation, payment, refund, and optimistic-update patterns
- `sql/005_reports.sql` - bounded operational and analytical queries
- `sql/006_security.sql` - least-privilege examples
- `tests/001_invariant_tests.sql` - zero-defect reconciliation queries
- `tests/test_project_files.py` - local package sanity checks
- `docs/data-dictionary.md` - grain and ownership summary
- `docs/production-checklist.md` - deployment evidence checklist

## Execution order

```text
psql -v ON_ERROR_STOP=1 -f sql/001_schema.sql
psql -v ON_ERROR_STOP=1 -f sql/002_seed.sql
psql -v ON_ERROR_STOP=1 -f sql/003_views.sql
psql -v ON_ERROR_STOP=1 -f tests/001_invariant_tests.sql
```

The workflow file contains bind placeholders such as `:order_id`; execute those statements through a database driver or adapt them to your client's parameter syntax. Do not commit production passwords or payment-provider secrets.
