INSERT INTO authors(author_id, author_name, country) VALUES
(1, 'Aarav Mehta', 'India'),
(2, 'Diya Kapoor', 'India'),
(3, 'Noah Williams', 'United Kingdom');

INSERT INTO books(book_id, author_id, title, price_paise, published_on) VALUES
(101, 1, 'Reliable SQL APIs', 59900, '2026-01-10'),
(102, 1, 'Transactions in Practice', 74900, '2026-02-12'),
(103, 2, 'GraphQL Query Design', 69900, '2026-03-05'),
(104, 3, 'DataLoader Patterns', 64900, '2026-04-18'),
(105, 2, 'Production Database Testing', 79900, '2026-05-22');

INSERT INTO reviews(review_id, book_id, rating, review_text, created_at) VALUES
(1, 101, 5, 'Clear and practical.', '2026-06-01T10:00:00Z'),
(2, 101, 4, 'Useful examples.', '2026-06-02T11:00:00Z'),
(3, 102, 5, 'Strong transaction coverage.', '2026-06-03T12:00:00Z'),
(4, 103, 4, 'Good resolver guidance.', '2026-06-04T13:00:00Z'),
(5, 104, 5, 'Excellent batching explanation.', '2026-06-05T14:00:00Z'),
(6, 104, 5, 'Solved our N+1 issue.', '2026-06-06T15:00:00Z');
