from __future__ import annotations

import argparse
import json
import sqlite3
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent


class CountingConnection:
    """Small teaching wrapper that counts executed SQL statements."""

    def __init__(self, connection: sqlite3.Connection):
        self.connection = connection
        self.query_count = 0

    def execute(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        self.query_count += 1
        return self.connection.execute(sql, tuple(params))

    def reset_count(self) -> None:
        self.query_count = 0

    def close(self) -> None:
        self.connection.close()


@dataclass(frozen=True)
class RequestContext:
    db: CountingConnection
    viewer_role: str = "reader"


class BatchLoader:
    """Synchronous request-scoped DataLoader-style batch/cache helper.

    Production GraphQL servers normally use an async DataLoader implementation.
    This intentionally small class makes the batching contract visible.
    """

    def __init__(self, batch_fn: Callable[[list[int]], dict[int, Any]]):
        self.batch_fn = batch_fn
        self.cache: dict[int, Any] = {}

    def load_many(self, keys: Iterable[int]) -> dict[int, Any]:
        ordered_unique = list(dict.fromkeys(int(k) for k in keys))
        missing = [k for k in ordered_unique if k not in self.cache]
        if missing:
            loaded = self.batch_fn(missing)
            for key in missing:
                self.cache[key] = loaded.get(key)
        return {key: self.cache.get(key) for key in ordered_unique}


class Repository:
    def __init__(self, db: CountingConnection):
        self.db = db

    def list_books(self, limit: int, after_id: int = 0) -> list[dict[str, Any]]:
        rows = self.db.execute(
            """SELECT book_id, author_id, title, price_paise, published_on, version
               FROM books
               WHERE book_id > ?
               ORDER BY book_id
               LIMIT ?""",
            (after_id, limit),
        ).fetchall()
        return [dict(row) for row in rows]

    def author_by_id(self, author_id: int) -> dict[str, Any] | None:
        row = self.db.execute(
            "SELECT author_id, author_name, country FROM authors WHERE author_id = ?",
            (author_id,),
        ).fetchone()
        return dict(row) if row else None

    def authors_by_ids(self, author_ids: list[int]) -> dict[int, dict[str, Any]]:
        if not author_ids:
            return {}
        placeholders = ",".join("?" for _ in author_ids)
        rows = self.db.execute(
            f"SELECT author_id, author_name, country FROM authors WHERE author_id IN ({placeholders})",
            author_ids,
        ).fetchall()
        return {int(row["author_id"]): dict(row) for row in rows}

    def review_count(self, book_id: int) -> int:
        row = self.db.execute(
            "SELECT COUNT(*) AS review_count FROM reviews WHERE book_id = ?",
            (book_id,),
        ).fetchone()
        return int(row["review_count"])

    def review_counts_by_book_ids(self, book_ids: list[int]) -> dict[int, int]:
        if not book_ids:
            return {}
        placeholders = ",".join("?" for _ in book_ids)
        rows = self.db.execute(
            f"""SELECT book_id, COUNT(*) AS review_count
                FROM reviews
                WHERE book_id IN ({placeholders})
                GROUP BY book_id""",
            book_ids,
        ).fetchall()
        counts = {int(row["book_id"]): int(row["review_count"]) for row in rows}
        return {book_id: counts.get(book_id, 0) for book_id in book_ids}


def _assert_reader(context: RequestContext) -> None:
    if context.viewer_role not in {"reader", "admin"}:
        raise PermissionError("viewer is not allowed to read the catalog")


def rest_books(context: RequestContext, limit: int = 20, after_id: int = 0) -> dict[str, Any]:
    """REST representation with explicit expansion and fixed query count."""
    _assert_reader(context)
    repo = Repository(context.db)
    books = repo.list_books(limit=min(max(limit, 1), 100), after_id=max(after_id, 0))
    author_map = repo.authors_by_ids([b["author_id"] for b in books])
    count_map = repo.review_counts_by_book_ids([b["book_id"] for b in books])
    items = []
    for book in books:
        items.append({
            "id": book["book_id"],
            "title": book["title"],
            "price_paise": book["price_paise"],
            "published_on": book["published_on"],
            "author": author_map.get(book["author_id"]),
            "review_count": count_map.get(book["book_id"], 0),
            "version": book["version"],
        })
    return {
        "items": items,
        "page": {
            "next_after_id": items[-1]["id"] if items else None,
            "limit": min(max(limit, 1), 100),
        },
    }


def graphql_books_naive(context: RequestContext, limit: int = 20) -> dict[str, Any]:
    """Resolver-shaped example that intentionally demonstrates 1 + N + N."""
    _assert_reader(context)
    repo = Repository(context.db)
    books = repo.list_books(limit=min(max(limit, 1), 100))
    nodes = []
    for book in books:
        nodes.append({
            "id": book["book_id"],
            "title": book["title"],
            "author": repo.author_by_id(book["author_id"]),
            "reviewCount": repo.review_count(book["book_id"]),
        })
    return {"data": {"books": {"nodes": nodes}}}


def graphql_books_batched(context: RequestContext, limit: int = 20) -> dict[str, Any]:
    """Request-scoped loaders reduce the same result to three statements."""
    _assert_reader(context)
    repo = Repository(context.db)
    books = repo.list_books(limit=min(max(limit, 1), 100))
    author_loader = BatchLoader(repo.authors_by_ids)
    count_loader = BatchLoader(repo.review_counts_by_book_ids)
    author_map = author_loader.load_many([b["author_id"] for b in books])
    count_map = count_loader.load_many([b["book_id"] for b in books])
    nodes = []
    for book in books:
        nodes.append({
            "id": book["book_id"],
            "title": book["title"],
            "author": author_map.get(book["author_id"]),
            "reviewCount": count_map.get(book["book_id"], 0),
        })
    return {"data": {"books": {"nodes": nodes}}}


def create_database(path: str = ":memory:") -> CountingConnection:
    raw = sqlite3.connect(path, check_same_thread=False)
    raw.row_factory = sqlite3.Row
    raw.executescript((ROOT / "schema.sql").read_text(encoding="utf-8"))
    raw.executescript((ROOT / "seed.sql").read_text(encoding="utf-8"))
    raw.commit()
    return CountingConnection(raw)


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "SQLMasteryAPI/1.0"

    def _write_json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    @property
    def context(self) -> RequestContext:
        return RequestContext(self.server.db)  # type: ignore[attr-defined]

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            self._write_json(200, {"status": "ok"})
            return
        if parsed.path == "/api/books":
            params = parse_qs(parsed.query)
            try:
                limit = int(params.get("limit", ["20"])[0])
                after_id = int(params.get("after", ["0"])[0])
                self.server.db.reset_count()  # type: ignore[attr-defined]
                result = rest_books(self.context, limit=limit, after_id=after_id)
                result["meta"] = {"sql_statements": self.server.db.query_count}  # type: ignore[attr-defined]
                self._write_json(200, result)
            except (ValueError, PermissionError) as exc:
                self._write_json(400, {"error": str(exc)})
            return
        self._write_json(404, {"error": "not found"})

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/graphql":
            self._write_json(404, {"error": "not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length) or b"{}")
            strategy = payload.get("strategy", "batched")
            limit = int(payload.get("variables", {}).get("limit", 20))
            self.server.db.reset_count()  # type: ignore[attr-defined]
            if strategy == "naive":
                result = graphql_books_naive(self.context, limit)
            elif strategy == "batched":
                result = graphql_books_batched(self.context, limit)
            else:
                raise ValueError("strategy must be 'naive' or 'batched'")
            result["extensions"] = {"sql_statements": self.server.db.query_count}  # type: ignore[attr-defined]
            self._write_json(200, result)
        except (ValueError, json.JSONDecodeError, PermissionError) as exc:
            self._write_json(400, {"errors": [{"message": str(exc)}]})

    def log_message(self, fmt: str, *args: Any) -> None:
        print("api:", fmt % args)


def run_server(host: str, port: int) -> None:
    db = create_database()
    server = ThreadingHTTPServer((host, port), ApiHandler)
    server.db = db  # type: ignore[attr-defined]
    print(f"REST:    http://{host}:{port}/api/books?limit=5")
    print(f"GraphQL: POST http://{host}:{port}/graphql")
    try:
        server.serve_forever()
    finally:
        db.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()
    run_server(args.host, args.port)


if __name__ == "__main__":
    main()
