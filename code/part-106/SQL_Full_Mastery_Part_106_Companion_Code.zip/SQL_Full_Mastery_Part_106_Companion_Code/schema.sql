PRAGMA foreign_keys = ON;

CREATE TABLE authors (
    author_id   INTEGER PRIMARY KEY,
    author_name TEXT NOT NULL,
    country     TEXT NOT NULL
);

CREATE TABLE books (
    book_id      INTEGER PRIMARY KEY,
    author_id    INTEGER NOT NULL REFERENCES authors(author_id),
    title        TEXT NOT NULL,
    price_paise  INTEGER NOT NULL CHECK (price_paise >= 0),
    published_on TEXT NOT NULL,
    version      INTEGER NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE reviews (
    review_id  INTEGER PRIMARY KEY,
    book_id    INTEGER NOT NULL REFERENCES books(book_id) ON DELETE CASCADE,
    rating     INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX ix_books_author_id ON books(author_id, book_id);
CREATE INDEX ix_reviews_book_id ON reviews(book_id, review_id);
