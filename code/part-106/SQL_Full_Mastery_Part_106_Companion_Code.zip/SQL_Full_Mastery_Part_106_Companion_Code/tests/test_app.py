import json
import sys
import unittest
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import (  # noqa: E402
    RequestContext,
    create_database,
    graphql_books_batched,
    graphql_books_naive,
    rest_books,
)


class ApiQueryShapeTests(unittest.TestCase):
    def setUp(self):
        self.db = create_database()
        self.context = RequestContext(self.db)

    def tearDown(self):
        self.db.close()

    def test_rest_uses_bounded_fixed_query_shape(self):
        self.db.reset_count()
        payload = rest_books(self.context, limit=5)
        self.assertEqual(5, len(payload["items"]))
        self.assertEqual(3, self.db.query_count)
        self.assertEqual(101, payload["items"][0]["id"])

    def test_naive_graphql_demonstrates_n_plus_one(self):
        self.db.reset_count()
        result = graphql_books_naive(self.context, limit=5)
        self.assertEqual(5, len(result["data"]["books"]["nodes"]))
        self.assertEqual(11, self.db.query_count)  # 1 + 5 authors + 5 counts

    def test_batched_graphql_preserves_result_with_three_queries(self):
        self.db.reset_count()
        naive = graphql_books_naive(self.context, limit=5)
        naive_nodes = naive["data"]["books"]["nodes"]
        self.db.reset_count()
        batched = graphql_books_batched(self.context, limit=5)
        self.assertEqual(naive_nodes, batched["data"]["books"]["nodes"])
        self.assertEqual(3, self.db.query_count)

    def test_pagination_is_stable_and_bounded(self):
        first = rest_books(self.context, limit=2)
        second = rest_books(
            self.context,
            limit=2,
            after_id=first["page"]["next_after_id"],
        )
        first_ids = [item["id"] for item in first["items"]]
        second_ids = [item["id"] for item in second["items"]]
        self.assertEqual([101, 102], first_ids)
        self.assertEqual([103, 104], second_ids)
        self.assertTrue(set(first_ids).isdisjoint(second_ids))

    def test_authorization_is_resolver_independent(self):
        blocked = RequestContext(self.db, viewer_role="anonymous")
        with self.assertRaises(PermissionError):
            rest_books(blocked, limit=1)
        with self.assertRaises(PermissionError):
            graphql_books_batched(blocked, limit=1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
