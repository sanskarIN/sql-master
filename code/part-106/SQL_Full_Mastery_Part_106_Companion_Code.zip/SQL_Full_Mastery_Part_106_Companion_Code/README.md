# SQL Full Mastery - Part 106 Companion Project

**Topic:** REST and GraphQL Database APIs, the N+1 Problem, and DataLoader  
**Author:** Ram Sandesh  
**Series:** SQL Full Mastery, Part 106 of 120

This zero-dependency Python project demonstrates the database behavior behind REST and GraphQL APIs. It uses only the Python standard library and an in-memory SQLite database.

## What it proves

- A bounded REST expansion can return books, authors, and review counts with three SQL statements.
- A naive resolver shape produces `1 + N + N` statements.
- Request-scoped batch loaders preserve the same result with three statements.
- Keyset pagination remains stable and bounded.
- Authorization is enforced below the transport surface.

The `/graphql` endpoint is intentionally a resolver-behavior teaching harness, not a full GraphQL parser or standards-compliant server. For production, use a maintained GraphQL implementation and preserve the same data-access contracts.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Run the server

```bash
python app.py --port 8080
```

REST request:

```bash
curl "http://127.0.0.1:8080/api/books?limit=5"
```

GraphQL-shaped batched request:

```bash
curl -X POST "http://127.0.0.1:8080/graphql" \
  -H "Content-Type: application/json" \
  -d '{"query":"books { nodes { id title author { author_name } reviewCount } }","variables":{"limit":5},"strategy":"batched"}'
```

Change `strategy` to `naive` and compare `extensions.sql_statements`.

## Files

- `schema.sql` - normalized schema, constraints, and supporting indexes
- `seed.sql` - deterministic sample data
- `app.py` - repository, REST shape, resolver shapes, batching, and HTTP server
- `tests/test_app.py` - query-count, result-equivalence, pagination, and authorization tests
- `examples/requests.http` - ready-to-copy HTTP requests

## Production checklist

Add authentication, per-field authorization, request deadlines, real connection pooling, structured logs, traces, query complexity controls, persisted-query policy, migration tooling, secrets management, TLS, rate limits, failure injection, and database-specific plan tests before deploying.

Open-source projects: https://www.github.com/sanskarIN  
Suggestions and inquiries: sanskarin@outlook.in
